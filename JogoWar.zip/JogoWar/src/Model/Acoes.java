package Model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


// Padr�o Singleton //
public class Acoes implements  ObservadoIF{
		
	private static Continente[] Continentes;
	private static Territorio[] listaTerritorios;
	private Exercito[] Exercitos;
	private Objetivo[] Objetivos;
	private Cartas C;
	private Jogador[] listaJogadores;
	boolean respInicializaJogo;
	private static Acoes ctrl = null;
	private int DadoAtk[] = new int[3];
	private int DadoDef[] = new int[3];
	private String[] nomes;
	private String[] cores;
	private int qtdJogadores;
	private int recebeCartaOuNao = 0; // 1 (Sim) e 0 (N�o)
	
	
	 private List<ObservadorIF> lst = new ArrayList<ObservadorIF>();
	

	private Acoes() {
	}
	
	public void add(ObservadorIF o) {
		lst.add(o);
	}
	private void atualiza() {
		Iterator<ObservadorIF> li =lst.iterator();		
		
		while(li.hasNext()) {
			ObservadorIF a = li.next();
			a.not(this);
		}

	}
	@Override
	public void remove(ObservadorIF o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int get(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	/////////////////////////////////////
	////// Inclu�dos no Observer  ///////
	/////////////////////////////////////
	
	public String[] getNomesJogadores() {
		String [] nomes = new String[listaJogadores.length];
		for (int i =0 ; i < listaJogadores.length;i++) {
			nomes[i] = listaJogadores[i].getnomeJogador();
		}
		
		return nomes;
	}
	
	public int getNumExercitos(String nomeTerritorio) {
		
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(nomeTerritorio) == true) {
				return listaTerritorios[i].getnumExercitos();
			}
		}
		
		return -1;
	}
	
	public String getCorDonoTerritorio(String nomeTerritorio) {
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(nomeTerritorio) == true) {
				
				return listaTerritorios[i].getCorExercito();
			}
		}
		
		return "Sem dono";
	}
	
	public Color[] getCorTodosTerritorios() {
		
		Color [] c =  new Color[listaTerritorios.length];
		
		for(int i=0;i<listaTerritorios.length;i++) {
			c[i]=getColorJava(listaTerritorios[i].getCorExercito());
		}
		
		return c;		
	}
	
	
	
	
	public int getRespostaRecebeCarta() {
		return recebeCartaOuNao;
	}
	
	public void setRespostaRecebeCarta(int n) {
		recebeCartaOuNao = n;
	}
	
	public Color getCorTerritorioJava(String nomeTerritorio) {
		
		Color c = null;
		
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(nomeTerritorio) == true) {
				c = getColorJava(listaTerritorios[i].getCorExercito());
				return c; 
			}
		}
		return c;
		
		
	}
	
	
	public void adicionaExercitoTerritorio(int qtd, String territorioAlvo) {

		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(territorioAlvo)==true) {
				listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()+qtd);
				break;
			}
		}
		
	}
	
	public boolean DeslocaExercitos(String territorioDoador, String territorioRecebedor, int qtdExRetirar) {
		
		// Verifica se o deslocamento pode ser feito //
		if (verificaDeslocamento(territorioDoador,territorioRecebedor)==false) {
			System.out.println("N�o passou por VerificaDeslocamento!");
			return false;
		}
		
		for(int i=0;i<listaTerritorios.length;i++) {
			// Retira os Ex�rcitos do Doador //
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(territorioDoador)==true) {
				listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()-qtdExRetirar);
			}
			// Coloca os Ex�rcitos no Recebedor //
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(territorioRecebedor)==true) {
				listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()+qtdExRetirar);
			}
		}
		
		return true;
		
	}
	
	
	
	
	
	////////////////////////////////////
	////////////////////////////////////
	
	
	// M�todos para o Controller //
	
	
	
	public static Acoes getAcoes() {
		if( ctrl == null) {
			ctrl = new Acoes();
		}
		
		return ctrl;
	} 
	
	
	
	// Verifica se o jogo pode ser iniciado, se sim inicia //
	public boolean inicializaJogo() {

		
		if(nomes[0]==null) {
			System.out.println("Erro ao receber os nomes dos Jogadores pela View!");
			return false;
		}
		if(cores[0]==null) {
			System.out.println("Erro ao receber as cores dos Jogadores pela View!");
			return false;
		}
		
		listaTerritorios = InicializaComponentes.getInicializaComponentes().inicializaTerritorios(listaTerritorios);	
		if(listaTerritorios[0].getNomeTerritorio() == null) {
			System.out.println("Erro ao inicializar os territ�rios!");
			return false; 
		}
		
		Continentes = InicializaComponentes.getInicializaComponentes().defineContinentes(listaTerritorios);
		if(Continentes[0].getNomeContinente() == null) {
			System.out.println("Erro ao inicializar os Continentes!");
			return false; 
		}
		
		listaJogadores = InicializaComponentes.getInicializaComponentes().defineJogadores(nomes, cores);
		if(listaJogadores[0].getnomeJogador() == null) {
			System.out.println("Erro ao inicializar os Jogadores!");
			return false;
		}
		
		Exercitos = InicializaComponentes.getInicializaComponentes().defineExercitos(listaJogadores);
		if(Exercitos[0].getCorExercito() == null) {
			System.out.println("Erro ao inicializar os Donos dos Ex�rcitos!");
			return false;
		}
		
		listaJogadores = InicializaComponentes.getInicializaComponentes().defineDonoTerritorios(listaJogadores, listaTerritorios, Exercitos, C);
		if (listaJogadores[0].getListaTerritorios()[0].getNomeTerritorio() == null) {
			System.out.println("Erro ao inicializar os Donos dos territ�rios!");
			return false;
		}
		
		Objetivos = InicializaComponentes.getInicializaComponentes().defineDonoObjetivos(listaJogadores, Objetivos, C);
		for (int i=0;i<listaJogadores.length;i++) {
			if(listaJogadores[i].getObjetivo()==null) {
				System.out.println("Erro ao inicializar os Donos dos objetivos! Jogador sem objetivo!!");
				return false;
			}
		}
			
		return true;		 
	}


	
	public int recebeExercitos(String jogadorAlvo) {
		
		int posJog = 0;
		int qtdExReceber = 0;
		int qtdmatchs = 0; // quantidade de territorios que o jogador possui no continente
		Territorio[] lstTerritorioCont;
		
		for (int i=0;i<listaJogadores.length;i++) {
			if(listaJogadores[i].getnomeJogador().contentEquals(jogadorAlvo)==true) {
				posJog=i;
				break;
			}
		}
		
		qtdExReceber = listaJogadores[posJog].getnumTerritoriosJog()/2;
		
		Territorio []lstTerritoriosJogador = listaJogadores[posJog].getListaTerritorios();
		
		// Verifica a posse de continentes //
		
		for(int i=0;i<Continentes.length;i++) {
			lstTerritorioCont = new Territorio[Continentes[i].getNumTerritorios()];
			lstTerritorioCont = Continentes[i].getTerritoriosContinente();
			for (int j=0; j < lstTerritorioCont.length;j++) {
				for(int k=0; k <listaJogadores[posJog].getnumTerritoriosJog();k++) {
					if(lstTerritorioCont[j].getNomeTerritorio().contentEquals(lstTerritoriosJogador[k].getNomeTerritorio())==true) {
						qtdmatchs = qtdmatchs + 1;
					}
				}
			}
			// Verifica se possui todos os territ�rios do continente //
			if(lstTerritorioCont.length == qtdmatchs) {
				switch(Continentes[i].getNomeContinente()) {
					case "America do Norte": qtdExReceber = qtdExReceber+5;break;
					case "America do Sul": qtdExReceber = qtdExReceber+2;break;
					case "Africa": qtdExReceber = qtdExReceber+3;break;
					case "Europa": qtdExReceber = qtdExReceber+5;break;
					case "Asia": qtdExReceber = qtdExReceber+7;break;
					case "Oceania": qtdExReceber = qtdExReceber+2;break;
				}
			}
			qtdmatchs = 0;
		}
		
		// Encontra o Ex�rcito do Jogador e incrementa//
		for(int i=0;i<Exercitos.length;i++) {
			if(Exercitos[i].getCorExercito().equals(listaJogadores[posJog].getColor())==true) {
				Exercitos[i].setQTDExercito(Exercitos[i].getQTDExercito()+qtdExReceber);
				break;
			}			
		}
		
		// Adiciona ex�rcitos para o jogador //
		listaJogadores[posJog].setNumExercitos(listaJogadores[posJog].getNumExercitos()+qtdExReceber);
		
		return qtdExReceber;
	}		
	

	
	// O resultado dos dados devem estar setados //
	// Realiza o ataque e caso seja bem sucedido, desloca as tropas //
	public boolean realizaAtaque(String TerritorioAtk, String TerritorioDef, String corJogadorAtk ) {
		
		int posTerritorioDef=0;
		int posTerritorioAtk=0;
		int posJogAtk = 0;
		int posJogDef = 0;
		
		if (validaAtaque(TerritorioAtk,TerritorioDef,corJogadorAtk) == false) {
			System.out.println("O ataque n�o foi validado");
			return false;
		}
		
		int[] resultado = comparaDados(DadoAtk,DadoDef);
		
		int ExercitosARetirarAtk =  resultado[1];
		int ExercitosARetirarDef =  resultado[2];
		
		
		
		// Encontra a posicao dos territ�rios //
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(TerritorioDef) == true) {
				posTerritorioDef = i;
			}
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(TerritorioAtk) == true) {
				posTerritorioAtk = i;
			}			
		}
		// Retira os Ex�rcitos mortos em batalha dos territ�rios //
		listaTerritorios[posTerritorioAtk].setNumExercitos(listaTerritorios[posTerritorioAtk].getnumExercitos()-ExercitosARetirarAtk);
		listaTerritorios[posTerritorioDef].setNumExercitos(listaTerritorios[posTerritorioDef].getnumExercitos()-ExercitosARetirarDef);

		

		
		// Ataque conquistou o territ�rio //
		if ( resultado[0] == 1) {
			
			
			
			System.out.println("ATAQUE GANHOU");
			for(int i=0;i<listaJogadores.length;i++) {
				recebeCartaOuNao = 1;
				// Jogador atacante //
				if(listaJogadores[i].getColor().contentEquals(corJogadorAtk)==true){
					posJogAtk = i;
					// Adiciona 1 Territ�rio ao total do jogador //
					listaJogadores[i].setnumTerritoriosJog(listaJogadores[i].getnumTerritoriosJog()+1);
					// Retira os ex�rcitos mortos em batalha da posse do jogador //
					listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()-ExercitosARetirarAtk);
					// Coloca o territ�rio ganho na lista de Territ�rios do Jogador //
					listaJogadores[i].setUmTerritorio(listaTerritorios[posTerritorioDef]);
					
				}
				
				// Jogador defensor //
				if (listaTerritorios[posTerritorioDef].getdonoTerritorio().contentEquals(listaJogadores[i].getnomeJogador())==true) {
					posJogDef= i;
					listaJogadores[i].setnumTerritoriosJog(listaJogadores[i].getnumTerritoriosJog()-1);
					listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()-ExercitosARetirarDef);
					listaJogadores[i].retiraTerritorio(listaTerritorios[posTerritorioDef]);
					
				}
			}
			
			// Troca o dono do Territ�rio //
			listaTerritorios[posTerritorioDef].setdonoTerritorio(listaJogadores[posJogAtk].getnomeJogador());
			// Muda a cor do Ex�rcito no territ�rio Defensor //
			listaTerritorios[posTerritorioDef].setCorExercito(corJogadorAtk);
			// Move a maior quantidade poss�vel de ex�rcitos para o territ�rio //
			listaTerritorios[posTerritorioDef].setNumExercitos((listaTerritorios[posTerritorioAtk].getnumExercitos()-1));
			listaTerritorios[posTerritorioAtk].setNumExercitos(1);
		}
		else {
			System.out.println("DEFESA GANHOU");
		}
		
		// Diminui o n�mero de Ex�rcitos dos Jogadores se necess�rio //
		for(int i=0;i<Exercitos.length;i++) {
			if(listaJogadores[posJogAtk].getColor().contentEquals(Exercitos[i].getCorExercito())==true) {
				Exercitos[i].setQTDExercito(Exercitos[i].getQTDExercito()-ExercitosARetirarAtk);
			}
			if(listaJogadores[posJogDef].getColor().contentEquals(Exercitos[i].getCorExercito())==true) {
				Exercitos[i].setQTDExercito(Exercitos[i].getQTDExercito()-ExercitosARetirarDef);
			}			
		}
		// Atualiza os Observadores //
		atualiza();
		return true;
		
	}
	
	public boolean verificaAtingiuObjetivo(String Jogador) {
		
		Objetivo O = new Objetivo();
		int posJog = 0;
		
		for(int i=0;i<listaJogadores.length;i++) {
			if(listaJogadores[i].getnomeJogador().contentEquals(Jogador)==true) {
				O = listaJogadores[i].getObjetivo();
				posJog = i;
				break;
			}
		}
		
		// Verifica se o jogador possui a quantidade necess�ria de territ�rios //
		if(O.getTerritorios()>listaJogadores[posJog].getnumTerritoriosJog()) {
			System.out.println("O Jogador ainda n�o conquistou a quantidade de territ�rios necess�rias");
			return false;
		}
		
		//  Verifica se o Ex�rcito alvo foi destru�do //
		for (int i=0;i<Exercitos.length;i++) {
			if(Exercitos[i].getCorExercito().contentEquals(O.getExercitos())==true) {
				
				if (Exercitos[i].getQTDExercito() > 0) {
					return false;
				}
			}
			
		}
		
		// Implementar a conquista de Continentes //
		
		
		
		return false;
	}
	
	
	// int [0] = vencedor (1,2)
	// int [1] = quantidade de ex perdido pelo atk
	// int [2] = quantidade de ex perdido pelo def
	public int[] comparaDados(int[] DadoAtk,int[] DadoDef) {
		
		
		int qtdDadoAtk = 0;
		int qtdDadoDef = 0;
		// resultado [0] = vencedor (1,2)
		// resultado [1] = quantidade de ex perdido pelo atk
		// resultado [2] = quantidade de ex perdido pelo def
		int [] resultado = new int[3];
		
		for(int i=0;i<3;i++) {
			if (DadoAtk[i] != 0) {
				qtdDadoAtk = qtdDadoAtk + 1;
			}
			if (DadoDef[i] != 0) {
				qtdDadoDef = qtdDadoDef + 1;
			}
		}
		
		// 1 ATK Vs 1 DEF //
		if (qtdDadoAtk==1 && qtdDadoDef ==1) {
			if (DadoAtk[0] > DadoDef[0]) {
				resultado[0] = 1;
				resultado[1] = 0;
				resultado[2] = 1;
				return resultado;
			}
			else {
				resultado[0] = 2;
				resultado[1] = 1;
				resultado[2] = 0;
				return resultado;
			}
		}
		// 1 Atk VS 2 DEF //
		if (qtdDadoAtk==1 && qtdDadoDef ==2) {
			if (DadoAtk[0] > DadoDef[0]) {
				// Venceu os dois dados da defesa //
				if (DadoAtk[0] > DadoDef[1]) {
					resultado[0] = 1;
					resultado[1] = 0;
					resultado[2] = 2;
					return resultado;
				}
				// Ganhou 1 mas perdeu 1, defesa vence mas perde um ex�rcito //
				else {
					resultado[0] = 2;
					resultado[1] = 1;
					resultado[2] = 1;
					return resultado;
				}
				
			}
			// Perdeu no primeiro dado //
			else {
				resultado[0] = 2;
				resultado[1] = 1;
				resultado[2] = 0;
				return resultado;
			}
		}
		
		
		
		// 1 Atk VS 3 DEF //
		if (qtdDadoAtk==1 && qtdDadoDef ==3) {
			if (DadoAtk[0] > DadoDef[0]) {
				// Venceu os dois dados da defesa //
				if (DadoAtk[0] > DadoDef[1]) {
					// Venceu os 3 dados da defesa //
					if (DadoAtk[0] > DadoDef[2]) {
						resultado[0] = 1;
						resultado[1] = 0;
						resultado[2] = 3;
						return resultado;
					}
					// Venceu os 2 dados da defesa mas perdeu 1 //
					else {
						resultado[0] = 2;
						resultado[1] = 1;
						resultado[2] = 2;
						return resultado;
					}
				}
				// Ganhou 1 mas perdeu 1, defesa vence mas perde um ex�rcito //
				else {
					resultado[0] = 2;
					resultado[1] = 1;
					resultado[2] = 1;
					return resultado;
				}
				
			}
			// Perdeu no primeiro dado //
			else {
				resultado[0] = 2;
				resultado[1] = 1;
				resultado[2] = 0;
				return resultado;
			}
		}
		
		// 2 Atk VS 1 DEF //
		if (qtdDadoAtk==2 && qtdDadoDef ==1) {
			if (DadoAtk[0] > DadoDef[0]) {
				resultado[0] = 1;
				resultado[1] = 0;
				resultado[2] = 1;
				return resultado;
			}
			else {
				if (DadoAtk[1]>DadoDef[0]) {
					resultado[0] = 1;
					resultado[1] = 1;
					resultado[2] = 1;
					return resultado;
				}
				// Perdeu nos dois dados //
				else {
					resultado[0] = 2;
					resultado[1] = 2;
					resultado[2] = 0;
					return resultado;
				}
				
			}
		}
				
		// 2 Atk VS 2 DEF //
		if (qtdDadoAtk==2 && qtdDadoDef ==2) {
			if (DadoAtk[0] > DadoDef[0]) {
				// ATK Ganhou os dois //
				if(DadoAtk[1] > DadoDef[1]) {
					resultado[0] = 1;
					resultado[1] = 0;
					resultado[2] = 2;
					return resultado;
				}
				// ATK Ganhou 1 e perdeu 1 //
				else {
					resultado[0] = 2;
					resultado[1] = 1;
					resultado[2] = 1;
					return resultado;
				}
				
			}
			// Perdeu no primeiro Dado //
			else {
					resultado[0] = 2;
					resultado[1] = 1;
					resultado[2] = 0;
					return resultado;
			}	
		}
		
		
		// 2 Atk VS 3 DEF //
		if (qtdDadoAtk==2 && qtdDadoDef ==3) {
			if (DadoAtk[0] > DadoDef[0]) {
				// ATK Ganhou os 2 //
				if(DadoAtk[1] > DadoDef[1]) {
					if (DadoAtk[1] > DadoDef[2]) {
						resultado[0] = 1;
						resultado[1] = 0;
						resultado[2] = 3;
						return resultado;
					}
					// ATK ganhou 2 dados e perdeu 1 //
					else {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 3;
						return resultado;
					}
					
				}
				// ATK ganhou 1 e DEF perdeu 1 //
				else {
						resultado[0] = 2;
						resultado[1] = 1;
						resultado[2] = 1;
						return resultado;
				}
					
			}
		}
			
				
		// 3 Atk VS 1 DEF //
		if (qtdDadoAtk==3 && qtdDadoDef ==1) {
			if (DadoAtk[0] > DadoDef[0]) {
				resultado[0] = 1;
				resultado[1] = 0;
				resultado[2] = 1;
				return resultado;
			}
			
			else {
				if (DadoAtk[1] > DadoDef[0]) {
					resultado[0] = 1;
					resultado[1] = 1;
					resultado[2] = 1;
					return resultado;
				}
				else {
					// ATK perdeu os 2 ataques //
					if (DadoAtk[2] > DadoDef[0]) {
						resultado[0] = 1;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
					// ATK perdeu os 3 ataques //
					else {
						resultado[0] = 2;
						resultado[1] = 3;
						resultado[2] = 0;
						return resultado;
						
					}
				}
			}
		}
		
		// 3 Atk VS 2 DEF //
		if (qtdDadoAtk==3 && qtdDadoDef ==2) {
			if (DadoAtk[0] > DadoDef[0]) {
				if (DadoAtk[1] > DadoDef[1]) {
					resultado[0] = 1;
					resultado[1] = 0;
					resultado[2] = 2;
					return resultado;
				}
				else {
					if (DadoAtk[2] > DadoDef[1]) {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 1;
						return resultado;
					}
					else {
						resultado[0] = 2;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
				}
			}
			
			else {
				if (DadoAtk[1] > DadoDef[0]) {
					if (DadoAtk[2] > DadoDef[1]) {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 2;
						return resultado;
					}
					else {
						resultado[0] = 2;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
				}
				else {
					// ATK perdeu os 2 ataques //
					if (DadoAtk[2] > DadoDef[0]) {
						resultado[0] = 2;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
					// ATK perdeu os 3 ataques //
					else {
						resultado[0] = 2;
						resultado[1] = 3;
						resultado[2] = 0;
						return resultado;
						
					}
				}
			}
		}
		
		
		// 3 Atk VS 3 DEF //
		if (qtdDadoAtk==3 && qtdDadoDef ==3) {
			if (DadoAtk[0] > DadoDef[0]) {
				if (DadoAtk[1] > DadoDef[1]) {
					if (DadoAtk[2] > DadoDef[2]) {
						resultado[0] = 1;
						resultado[1] = 0;
						resultado[2] = 3;
						return resultado;
					}
					else {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 3;
						return resultado;
					}
				}
				else {
					if (DadoAtk[2] > DadoDef[2]) {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 3;
						return resultado;
					}
					else {
						resultado[0] = 2;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
				}
			}
			
			
			else {
				if (DadoAtk[1] > DadoDef[1]) {
					if (DadoAtk[2] > DadoDef[2]) {
						resultado[0] = 1;
						resultado[1] = 1;
						resultado[2] = 3;
						return resultado;
					}
					else {
						if (DadoAtk[2] > DadoDef[0]) {
							resultado[0] = 2;
							resultado[1] = 2;
							resultado[2] = 1;
							return resultado;
						}
					}
				}
				else {
					// ATK perdeu os 2 ataques //
					if (DadoAtk[2] > DadoDef[2]) {
						resultado[0] = 2;
						resultado[1] = 2;
						resultado[2] = 1;
						return resultado;
					}
					// ATK perdeu os 3 ataques //
					else {
						resultado[0] = 2;
						resultado[1] = 3;
						resultado[2] = 0;
						return resultado;
						
					}
				}
			}
		}
		
		return resultado;
		
		
	}
	
		
	public boolean validaAtaque(String TerritorioAtk, String TerritorioDef, String corJogador) {
		
		
		int numT = 0;
		String []Fronteiras;
		
		
		for (int i=0; i <listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(TerritorioAtk)==true) {
				numT = i;
				if (listaTerritorios[i].getnumExercitos()<2) {
					System.out.println("Sem ex�rcitos suficientes para realizar o ataque!");
					return false;
				}
				if(listaTerritorios[i].getCorExercito().contentEquals(corJogador)==false) {
					System.out.println("O territ�rio atacante n�o pertence ao jogador!");
					return false;
				}
			}
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(TerritorioDef)==true) {
				if (listaTerritorios[i].getCorExercito().contentEquals(corJogador)==true) {
					System.out.println("O jogador n�o pode atacar o pr�prio territ�rio!");
					return false;
				}
			}
		}
		
	
		Fronteiras = new String[listaTerritorios[numT].getFronteiras().length];
		Fronteiras = listaTerritorios[numT].getFronteiras();
		
		for (int i=0; i<Fronteiras.length;i++) {
			if(Fronteiras[i]!= null) {
				if(Fronteiras[i].contentEquals(TerritorioDef)==true) {
					return true;
				}
			}
		}
		
		
		System.out.println("Os Territ�rios n�o fazem fronteira");
		
		
		return false;
		
	}
		
	public void setDadoAtk(int[] atk) {
		DadoAtk[0] = atk[0];
		DadoAtk[1] = atk[1];
		DadoAtk[2] = atk[2];
	}
	
	public void setDadoDef(int[] def) {
		DadoDef[0] = def[0];
		DadoDef[1] = def[1];
		DadoDef[2] = def[2];
	}
	
	// atk = 1 // Def = 2
	public int getResultadoDado() {
		
		Dado d = new Dado();
		int valor = d.getResultadoDado();			
		
		
		return valor;
		
	}
	
	public String getJogadorAlvo(int posJogador) {
		 return listaJogadores[posJogador].getnomeJogador();
		}
	
	public Territorio[] getListaTerritorios() {
		return listaTerritorios;
	}
	
	private Color getColorJava(String col) {
		Color color = null;
		if (col==null) {System.out.println("TERRITORIO COM COR NULL +++++++++++++");}
	    switch (col.toLowerCase()) {
	    case "preto":
	        color = Color.BLACK;
	        break;
	        
	    case "azul":
	        color = Color.BLUE;
	        break;
	        
	    case "verde":
	        color = Color.GREEN;
	        break;
	        
	    case "branco":
	        color = Color.WHITE;
	        break;
	        
	    case "amarelo":
	        color = Color.YELLOW;
	        break;
	    case "vermelho":
	        color = Color.RED;
	        break;	    
	        }
	    return color;
	   }
	
	public String[] getListaTerritoriosString(int posJogAlvo) {
		
		Territorio[] T = listaJogadores[posJogAlvo].getListaTerritorios();
		String []S = new String[listaJogadores[posJogAlvo].getnumTerritoriosJog()];
		for(int i=0;i<listaJogadores[posJogAlvo].getnumTerritoriosJog();i++) {
			S[i] = T[i].getNomeTerritorio();
		}
		
		return S;
		
	}
	
	public int getQtdExercitosJogador(int posJogAlvo) {
		int qtd = listaJogadores[posJogAlvo].getNumExercitos();
		
		return qtd;
	}

	

	
	
	public Exercito[] getListaExercitos() {
		return Exercitos;
	}
	
	public Continente[] getListaContinentes() {
		return Continentes;
	}
	
	public String[][] getObjetivosJogador(String nomeJogador) {
		String o[] = new String[2];
		String c[] = new String[2];
		
		String resposta[][]= new String[2][2];
		
		
		for (int i=0; i < this.Objetivos.length;i++) {
			 // Encontra o Objetivo do jogador //
			if( Objetivos[i].getDonoObjetivo()!= null) {
				if(Objetivos[i].getDonoObjetivo().equals(nomeJogador) == true) {
					if(Objetivos[i].getExercitos()==null) {
						o[0] = "nenhum";
					}
					else {
						o[0]= Objetivos[i].getExercitos();
					}
					
					o[1]= Integer.toString((Objetivos[i].getTerritorios()));
					if(Objetivos[i].getContinentes()!=null) {
						c = Objetivos[i].getContinentes();
											
					}
					resposta[0][0] = o[0];
					resposta[0][1] = o[1];
					resposta[1][0] = c[0];
					resposta[1][1] = c[1];
					return resposta;
				}
				
				
			}
		}
		
		return null;
	}

	private boolean verificaDeslocamento(String nomeTerritorio1,String nomeTerritorio2) {
		
		
		String dono1 = null;
		String dono2 = null;
		String Front[];
		int pos1 = 0;
		
		
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(nomeTerritorio1)==true) {				
				dono1 = listaTerritorios[i].getdonoTerritorio();
				System.out.println("O Territ�rio "+nomeTerritorio1+" pertence ao jogador "+dono1);
				pos1 = i;
			}
			if(listaTerritorios[i].getNomeTerritorio().contentEquals(nomeTerritorio2)==true) {
				dono2 = listaTerritorios[i].getdonoTerritorio();
				System.out.println("O Territ�rio "+nomeTerritorio2+" pertence ao jogador "+dono2);
			}
		}
		
		
		
		if(dono1.contentEquals(dono2)==false) {
			System.out.println("Territ�rios com donos diferentes!");
			return false;
		}
		
		Front = new String[listaTerritorios[pos1].getFronteiras().length];
		Front = listaTerritorios[pos1].getFronteiras();
		for(int i=0; i < Front.length;i++) {
			if(Front[i] !=null) {
				if(Front[i].contentEquals(nomeTerritorio2)==true) {
					System.out.println("O Territ�rio "+nomeTerritorio1+" Faz fronteira com o Territ�rio "+nomeTerritorio2);
					return true;
				}
			}
		}
		System.out.println("Os Territ�rios n�o fazem fronteira");
		
		return false;
		
		
	}

	
	public int[] getOrdemJogadores() {
		int []vetor = new int[listaJogadores.length];
		for(int i=0;i<listaJogadores.length;i++) {
			vetor[i]=listaJogadores[i].getOrdemJogador();
		}
		return vetor;
	}


	public void setNomes(String nm) {
		for (int i=0;i<nomes.length;i++) {
			if(nomes[i]==null) {
				nomes[i]=nm;
				break;
			}
		}

	}
	
	public void setCores(String cr) {

		for( int i=0; i < cores.length; i++) {
			if(cores[i]==null) {
				cores[i]=cr;
				break;
			}
		}
	}
	
	public void setQtdJogadores(int n) {
		qtdJogadores = n;
		nomes = new String[qtdJogadores];
		cores = new String[qtdJogadores];
	}


	
	
}


