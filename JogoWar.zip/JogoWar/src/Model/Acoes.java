package Model;
import java.util.Scanner;
class Acoes {
	Scanner numE = new Scanner(System.in);
	
	private boolean validaAtaque(String cor,String nomeTOrigem,String nomeTDestino){
			
		InicializaJogo a = new InicializaJogo();
		Jogador[] J = a.getListaJogadores();
		Territorio[] T;
		String[] S;
		int i=0;
		boolean terr = false;
		
		while(J[i].getColor().equals(cor) == false) {
			i++;
		}
		
		T = J[i].getListaTerritorios();
		
		// Verifica se o jogador possui este territ�rio //
		for ( i =0; i < T.length;i++) {
			if(T[i].getNomeTerritorio().equals(nomeTOrigem) == true) {
				terr= true;
				break;
			}
		}
		if ( terr == false) {
			System.out.println("O Territ�rio n�o � do Jogador");
			return false;
		}
		S = T[i].getFronteiras();
		
		terr = false;
		
		// Verifica se existe Fronteira entre os dois //
		for (i=0;i<S.length;i++) {
			if (S[i].equals(nomeTDestino) ) {
				terr=true;
				break;
			}			
		}
		
		if (terr==false) {
			System.out.println("O Territ�rio de Origem n�o faz fronteira com o Teerit�rio DEstino");
		}
		
		return true;
	}
	
	
	protected void recebeExercitos(Jogador[] listaJogadores, String jogadorAlvo,Territorio[] listaTerritorios) {
		
		
		int i=0,numExercitos=0,numTemp=0;
		boolean sinal = false;
		String sTemp;
		Territorio[] T;
		while(listaJogadores[i].getnomeJogador().equals(jogadorAlvo) == false) {
			i++;
		}
		
		numExercitos = listaJogadores[i].getnumTerritoriosJog()/2;
		
		listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()+numExercitos);
		System.out.println("JOGADOR ALVO: "+listaJogadores[i].getnomeJogador());

		while(numExercitos>0) {
			System.out.println("Voc� possui "+numExercitos+" unidades de Exercito dispon�veis");
			System.out.println("Quantos unidades deseja colocar no territ�rio alvo?");
			
			numTemp = numE.nextInt();
			if(numTemp > numExercitos) {
				System.out.println("Essa quantidade n�o est� dispon�vel!!");
			}
			else {
				System.out.println("Qual territ�rio deseja colocar suas unidades?");
				
				sTemp = numE.next();
				
				// Verifica se o Territorio pertence ao jogador //
				for(i=0;i<listaTerritorios.length;i++) {
					if(listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
						if(listaTerritorios[i].getdonoTerritorio().equals(jogadorAlvo) == true) {
							sinal = true;
						}
					}
				}
				// Coloca as unidades no territorio alvo caso seja //
				if (sinal == true) {
					for (i=0; i <listaTerritorios.length;i++) {
						if (listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
							listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()+numTemp);
						}
					}
					numExercitos = numExercitos - numTemp;
				}
				else {
					System.out.println("Este territ�rio n�o pertence ao jogador");
				}
				
				
			}
			sinal = false;
			
			
			
			
		}		
	}
}
