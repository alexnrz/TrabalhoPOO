package Model;

class Acoes {
	
	private boolean validaAtaque(String cor,String nomeTOrigem,String nomeTDestino){
			
		
		
		
		// Implementar //
		return true;
	}
	
	
	protected void recebeExercitos(Jogador[] listaJogadores, String jogadorAlvo) {
		
		int i=0,numExercitos=0;
		while(listaJogadores[i].getnomeJogador().equals(jogadorAlvo) == false) {
			i++;
		}
		
		
		numExercitos = listaJogadores[i].getnumTerritoriosJog()/2;
		
		listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()+numExercitos);
		
		
		
	}
}
