package Model;
import java.util.Scanner;


// Padr�o Singleton //
public class Acoes {
	Scanner numE = new Scanner(System.in);
	static int numeroDeTerritorios = 9; // N�mero de pa�ses //	
	static int numContinentes = 2;
		
	static Continente[] Continentes;
	static Territorio[] listaTerritorios;
	private Exercito[] Exercitos;
	private Objetivo[] Objetivos;
	private Cartas C;
	private Jogador[] listaJogadores;
	boolean respInicializaJogo;
	String[] StrJogadores;
	String[] CorJogadores;
	private static Acoes ctrl = null;
	private int DadoAtk;
	private int DadoDef;
	


	private Acoes() {}
	
	public static Acoes getAcoes() {
		if( ctrl == null) {
			ctrl = new Acoes();
		}
		
		return ctrl;
	} 
	
	
	
	// Verifica se o jogo pode ser iniciado, se sim inicia //
	public boolean inicializaJogo(String[] StrJogadores, String[] CorJogadores) {

		
		if(StrJogadores[0]==null) {
			System.out.println("Erro ao receber os nomes dos Jogadores pela View!");
			return false;
		}
		if(CorJogadores[0]==null) {
			System.out.println("Erro ao receber as cores dos Jogadores pela View!");
			return false;
		}
		
		listaTerritorios = InicializaComponentes.getInicializaComponentes().inicializaTerritorios(listaTerritorios);	
		if(listaTerritorios[0].getNomeTerritorio() == null) {
			System.out.println("Erro ao inicializar os territ�rios!");
			return false; 
		}
		
		Continentes = InicializaComponentes.getInicializaComponentes().defineContinentes(listaTerritorios);
		if(Continentes[0].getNomeContinente() == null) {
			System.out.println("Erro ao inicializar os Continentes!");
			return false; 
		}
		
		listaJogadores = InicializaComponentes.getInicializaComponentes().defineJogadores(StrJogadores, CorJogadores);
		if(listaJogadores[0].getnomeJogador() == null) {
			System.out.println("Erro ao inicializar os Jogadores!");
			return false;
		}
		
		Exercitos = InicializaComponentes.getInicializaComponentes().defineExercitos(listaJogadores);
		if(Exercitos[0].getCorExercito() == null) {
			System.out.println("Erro ao inicializar os Donos dos Ex�rcitos!");
			return false;
		}
		
		listaJogadores = InicializaComponentes.getInicializaComponentes().defineDonoTerritorios(listaJogadores, listaTerritorios, Exercitos, C);
		if (listaJogadores[0].getListaTerritorios()[0].getNomeTerritorio() == null) {
			System.out.println("Erro ao inicializar os Donos dos territ�rios!");
			return false;
		}
		
		Objetivos = InicializaComponentes.getInicializaComponentes().defineDonoObjetivos(listaJogadores, Objetivos, C);
		if(Objetivos[0].getDonoObjetivo()==null && Objetivos[1].getDonoObjetivo()==null && Objetivos[2].getDonoObjetivo()==null) {
			System.out.println("Erro ao inicializar os Donos dos objetivos!");
			return false;
		}
		
		return true;		 
	}


	
	protected void recebeExercitos(Jogador[] listaJogadores, String jogadorAlvo,Territorio[] listaTerritorios) {
		
	
		Continente[] C = getListaContinentes();
		int i=0,numExercitos=0,numTemp=0,contador=0,Contp=0;
		boolean sinal = false;
		String sTemp;
		Territorio[] T;
		Territorio[] TCont = new Territorio[8];
		while(listaJogadores[i].getnomeJogador().equals(jogadorAlvo) == false) {
			i++;
		}
		
		// Verifica se tem exercitos bonus para receber //
		T = listaJogadores[i].getListaTerritorios();
		System.out.println("JOGADOR ALVO: "+listaJogadores[i].getnomeJogador());
		System.out.println("Territorios do Jogador:");
		for(int j=0; j < listaJogadores[i].getnumTerritoriosJog();j++) {
			if(T[j].getNomeTerritorio()!=null) {
				System.out.println("   " + T[j].getNomeTerritorio());
			}
		}
		
		for(int k=0; k < C.length; k++) {
			TCont=C[k].getTerritoriosContinente();
			for ( int z=0; z < C[0].getNumTerritorios();z++) {
				for (int j=0; j < listaJogadores[i].getnumTerritoriosJog();j++) {
					if(TCont[z].getNomeTerritorio().equals(T[j].getNomeTerritorio()) == true) {
						contador = contador + 1;
						break;
					}
				}
			}
			// Caso true, o jogador possui o b�nus por esse continente //
			if (contador == C[k].getNumTerritorios()) {
				Contp = Contp+1;
			}		
			contador=0;
		}
		
		// B�nus atualmente � de 2 por Continente //
		// Contp = exercitos b�nus //
		
		numExercitos = (2*Contp) + (listaJogadores[i].getnumTerritoriosJog())/2;
		
		listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()+numExercitos);
		

		while(numExercitos>0) {
			System.out.println("Voc� possui "+numExercitos+" unidades de Exercito dispon�veis");
			System.out.println("Quantos unidades deseja colocar no territ�rio alvo?");
			
			numTemp = numE.nextInt();
			if(numTemp > numExercitos) {
				System.out.println("Essa quantidade n�o est� dispon�vel!!");
			}
			else {
				System.out.println("Qual territ�rio deseja colocar suas unidades?");
				
				sTemp = numE.next();
				
				// Verifica se o Territorio pertence ao jogador //
				for(i=0;i<listaTerritorios.length;i++) {
					if(listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
						if(listaTerritorios[i].getdonoTerritorio().equals(jogadorAlvo) == true) {
							sinal = true;
						}
					}
				}
				// Coloca as unidades no territorio alvo caso seja //
				if (sinal == true) {
					for (i=0; i <listaTerritorios.length;i++) {
						if (listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
							listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()+numTemp);
						}
					}
					numExercitos = numExercitos - numTemp;
				}
				else {
					System.out.println("Este territ�rio n�o pertence ao jogador");
				}
				
				
			}
			sinal = false;
			
			
			
		}		
	}

	
	public int comparaDados(int DadoAtk[],int[] DadoDef) {
		
		int atk = 0;
		int def = 0;
		
		if ( DadoAtk[0] > DadoDef[0]) {
			atk = atk + 1;
		}
		else {
			def = def + 1;
		}
		
		if ( DadoAtk[1] > DadoDef[1]) {
			atk = atk + 1;
		}
		else {
			def = def + 1;
		}
		
		if ( DadoAtk[2] > DadoDef[2]) {
			atk = atk + 1;
		}
		else {
			def = def + 1;
		}
		
		
		if ( atk > def) {
			return 1;
		}
		else {
			return 2;
		}
		
		
	}
	
	
	public boolean validaAtaque(String TerritorioAtk, String TerritorioDef, String corJogador) {
		
		
		int flag = 0;
		int numT = 0;
		String []Fronteiras;
		
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getCorExercito().contentEquals(corJogador)==true) {
				flag = 1;
				numT = i;
				break;
			}
		}		
		if(flag == 0) {
			System.out.println("O Territ�rio n�o pertence ao jogador");
			return false;
		}
		
		
		Fronteiras = listaTerritorios[numT].getFronteiras();
		
		
		for (int i=0; i<Fronteiras.length;i++) {
			if(Fronteiras[i].contentEquals(TerritorioDef)==true) {
				return true;
			}
		}
		
		
		System.out.println("Os Territ�rios n�o fazem fronteira");
		
		
		return false;
		
	}
		
	public void setDadoAtk(int atk) {
		DadoAtk = atk;
	}
	
	public void setDadoDef(int def) {
		DadoDef = def;
	}
	
	// atk = 1 // Def = 2
	public int getResultadoDado() {
		
		Dado d = new Dado();
		int valor = d.getResultadoDado();			
		
		
		return valor;
		
	}
	
	public Jogador[] getListaJogadores() {
		return listaJogadores;
	}
	
	public Territorio[] getListaTerritorios() {
		return listaTerritorios;
	}
	
	public Exercito[] getListaExercitos() {
		return Exercitos;
	}
	
	public Continente[] getListaContinentes() {
		return Continentes;
	}
	public int getNumExercitos(String nomeTerritorio) {
		
		for(int i=0;i<listaTerritorios.length;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(nomeTerritorio) == true) {
				return listaTerritorios[i].getnumExercitos();
			}
		}
		
		return -1;
	}
	
	public String getCorDonoTerritorio(String nomeTerritorio) {
		for(int i=0;i<51;i++) {
			if(listaTerritorios[i].getNomeTerritorio().equals(nomeTerritorio) == true) {
				
				return listaTerritorios[i].getCorExercito();
			}
		}
		
		return "Sem dono";
	}
	
	
	public String[] getNomesJogadores() {
		String [] nomes = new String[listaJogadores.length];
		for (int i =0 ; i < listaJogadores.length;i++) {
			nomes[i] = listaJogadores[i].getnomeJogador();
		}
		
		return nomes;
	}
	
	public String[] getObjetivosJogador(String nomeJogador) {
		String o[] = new String[3];
		String c[];
		for (int i=0; i < this.Objetivos.length;i++) {
			 // Encontra o Objetivo do jogador //
			if( Objetivos[i].getDonoObjetivo()!= null) {
				if(Objetivos[i].getDonoObjetivo().equals(nomeJogador) == true) {
					o[0]= Objetivos[i].getExercitos();
					o[1]= String.valueOf(Objetivos[i].getTerritorios());
					if(Objetivos[i].getContinentes()!=null) {
						c = new String[Objetivos[i].getContinentes().length];
						c = Objetivos[i].getContinentes();
						for(int j=0;j<Objetivos[i].getContinentes().length-1;j++) {
							c[0].concat(c[j+1]);
							o[2] = c[0];
						}
					
					
						
					}
					
					return o;
				}
				
				
			}
		}
		
		return null;
	}

}


