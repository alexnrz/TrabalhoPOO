package Model;

class Acoes {
	
	private boolean validaAtaque(String cor,String nomeTOrigem,String nomeTDestino){
			
		
		
		
		// Implementar //
		return true;
	}
}
