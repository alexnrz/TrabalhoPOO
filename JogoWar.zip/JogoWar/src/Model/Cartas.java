package Model;
import java.util.Random;
class Cartas {

	
	

	
	/* Retorna um objetivo, verifica se h� objetivos dispon�veis, verifica se o jogador existe //
	// e verifica se o jogador alvo j� possui um objetivo */
	protected Objetivo retiraCartaObjetivo(Objetivo[] Objetivos, Jogador[] Jogadores, String nomeJogador) {
		
		int numObjetivo, posJogador=0,i=0;
		int totalObjetivos = Objetivos.length;
		Random gerador = new Random(); 
		
		Objetivo ObjetivoJogador = new Objetivo();

		numObjetivo = gerador.nextInt(totalObjetivos);
		while(Objetivos[numObjetivo].getDonoObjetivo()!=null) {
			numObjetivo = gerador.nextInt(totalObjetivos);
			i++;
			
			if (i > totalObjetivos) {
				System.out.println("Todos os Objetivos foram preenchidos!");
				return null;
			}
		}
		
		while(Jogadores[posJogador].getnomeJogador().equals(nomeJogador) == false) {
			posJogador++;
			if (posJogador > 6) {
				System.out.println("Jogador n�o encontrado para definir um objetivo");
				return null;
			}
		}
		
		if ( Jogadores[posJogador].getObjetivo() != null) {
			System.out.println("O jogador ja possui um objetivo!");
			return null;
		}
		
		ObjetivoJogador = Objetivos[numObjetivo];
		
		return ObjetivoJogador;		
	}
	
	
	/* Retorna um territ�rio, verifica se o jogador alvo existe, verifica se h� territ�rios
	 * dispon�veis */
	protected Territorio retiraCartaTerritorio(Territorio[] listaTerritorios,Jogador[] Jogadores, String nomeJogador) {
		int totalTerritorios=listaTerritorios.length;
		int numTerritorio,posJogador=0,i=0;
		Random gerador = new Random();
		Territorio cartaTerritorio;
		
		numTerritorio = gerador.nextInt(totalTerritorios);
		while(listaTerritorios[numTerritorio].getdonoTerritorio() != null) {

			numTerritorio = gerador.nextInt(totalTerritorios);
			i++;
			if ( i > totalTerritorios) {
				System.out.println("Todos os Territorios foram preenchidos!");
				return null;
			}
		}
		
		while(Jogadores[posJogador].getnomeJogador() != nomeJogador) {
			posJogador++;
			if (posJogador > 6) {
				System.out.println("Jogador n�o encontrado para receber um Territ�rio");
				return null;
			}
		}
		listaTerritorios[numTerritorio].setCorExercito(Jogadores[posJogador].getColor());
		listaTerritorios[numTerritorio].setNumExercitos(1);
		listaTerritorios[numTerritorio].setdonoTerritorio(nomeJogador);
	
		
		cartaTerritorio = listaTerritorios[numTerritorio];		
		
		return cartaTerritorio;	
	}
	
	
}
