package Model;
import java.util.Random;
class Cartas {

	
	

	
	/* Retorna um objetivo, verifica se h� objetivos dispon�veis, verifica se o jogador existe //
	// e verifica se o jogador alvo j� possui um objetivo */
	protected Objetivo retiraCartaObjetivo(Objetivo[] Objetivos, Jogador[] Jogadores, String nomeJogador) {
		
		int numObjetivo, posJogador=0,i=0;
		int totalObjetivos = Objetivos.length;
		int flag = 0;
		Random gerador = new Random(); 
		
		
		Objetivo ObjetivoJogador = new Objetivo(); 

		numObjetivo = gerador.nextInt(totalObjetivos);
		
		while(i < Objetivos.length || flag != 0) {
			if(Objetivos[numObjetivo].getDonoObjetivo()==null) {
				for (int j=0;j<Jogadores.length;j++) {
					// Verifica se existe um jogador da cor que o objetivo deseja eliminar //
					if(Jogadores[j].getColor().equals(Objetivos[numObjetivo].getExercitos())==true) {
						// Verifica se o jogador a ser derrotado n�o � o mesmo que vai receber a carta //
						if(Jogadores[j].getnomeJogador().equals(nomeJogador)==false) {
							flag=1;
							break;
						}
					}
				}
			}
			if(flag == 0) {
				i++;
				numObjetivo = gerador.nextInt(totalObjetivos);
			}
		}
		
		// Verifica se o jogador alvo est� mesmo no jogo //
		while(Jogadores[posJogador].getnomeJogador().equals(nomeJogador) == false) {
			posJogador++;
			if (posJogador > 6) {
				System.out.println("Jogador n�o encontrado para definir um objetivo");
				return null;
			}
		}
		// Verifica se o jogador alvo j� possui um Objetivo //
		if ( Jogadores[posJogador].getObjetivo() != null) {
			System.out.println("O jogador ja possui um objetivo!");
			return null;
		}
		
		Objetivos[numObjetivo].setDonoObjetivo(Jogadores[posJogador].getnomeJogador());
		
		ObjetivoJogador = Objetivos[numObjetivo];
		
		return ObjetivoJogador;		
	}
	
	
	/* Retorna um territ�rio, verifica se o jogador alvo existe, verifica se h� territ�rios
	 * dispon�veis */
	protected Territorio retiraCartaTerritorio(Territorio[] listaTerritorios,Jogador[] Jogadores, String nomeJogador) {
		int totalTerritorios=listaTerritorios.length;
		int numTerritorio,posJogador=0,i=0;
		Random gerador = new Random();
		Territorio cartaTerritorio;
		
		numTerritorio = gerador.nextInt(totalTerritorios);
		while(listaTerritorios[numTerritorio].getdonoTerritorio() != null) {

			numTerritorio = gerador.nextInt(totalTerritorios);
			i++;
			if ( i > totalTerritorios) {
				break;
			}
		}
		
		while(Jogadores[posJogador].getnomeJogador() != nomeJogador) {
			posJogador++;
			if (posJogador > 6) {
				System.out.println("Jogador n�o encontrado para receber um Territ�rio");
				return null;
			}
		}
		listaTerritorios[numTerritorio].setCorExercito(Jogadores[posJogador].getColor());
		listaTerritorios[numTerritorio].setNumExercitos(listaTerritorios[numTerritorio].getnumExercitos()+1);
		listaTerritorios[numTerritorio].setdonoTerritorio(nomeJogador);
	
		
		cartaTerritorio = listaTerritorios[numTerritorio];		
		
		return cartaTerritorio;	
	}
	

		
		
		
	
}
