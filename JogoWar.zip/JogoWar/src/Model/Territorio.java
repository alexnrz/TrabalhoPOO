package Model;

class Territorio {

	private String nomeTerritorio;
	private int numTerritorio;
	private String donoTerritorio;
	private int numExercitos;
	private String Fronteiras[];
	
	
	/* Nome Territ�rio */
	private String getNomeTerritorio() {
		return nomeTerritorio;
	}
	private void setNomeTerritorio(String nomeT) {
		nomeTerritorio = nomeT;
	}
	
	/* Numero Territ�rio*/
	
	private int getNumTerritorio() {
		return numTerritorio;
	}
	private void setNumTerritorio(int num) {
		numTerritorio = num;
	}
	
	/* Jogador dono Territ�rio */
	private String getdonoTerritorio() {
		return donoTerritorio;
	}
	private void setdonoTerritorio(String donoT) {
		donoTerritorio = donoT;
	}
	
	/* Exercitos */
	private int getnumExercitos() {
		return numExercitos;
	}
	private void setnumExercitos(int num) {
		numExercitos = num;
	}	
	
	/* Fronteiras */
	private String[] getFronteiras() {
		return Fronteiras;
	}
	private void setFronteiras(String[] Front) {
		
		Fronteiras = new String[Front.length]; // Aloca��o de espa�o para vetor //
		for(int i=0; i < Front.length; i++) {  // 			Testar 				//
			Fronteiras[i]=Front[i];			
		}
	}
	
	
	
	
}
