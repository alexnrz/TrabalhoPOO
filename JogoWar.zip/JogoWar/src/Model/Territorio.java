package Model;

class Territorio {

	private String nomeTerritorio;
	private int numTerritorio;
	private String donoTerritorio;
	private int numExercitos;
	private String Fronteiras[];
	
	public Territorio( String nomeT, int numTer,
		int numE,String []Front) {
		
		nomeTerritorio = nomeT;
		numTerritorio = numTer;
		numExercitos = numE;
		donoTerritorio = null;
		setFronteiras(Front);		
	}
	
	
	/* Nome Territ�rio */
	private String getNomeTerritorio() {
		return nomeTerritorio;
	}	
	
	/* Numero Territ�rio*/
	private int getNumTerritorio() {
		return numTerritorio;
	}
	
	/* Jogador dono Territ�rio */
	protected String getdonoTerritorio() {
		return donoTerritorio;
	}
	protected void setdonoTerritorio(String donoT) {
		donoTerritorio = donoT;
	}
	
	/* Exercitos */
	private int getnumExercitos() {
		return numExercitos;
	}
	
	/* Fronteiras */
	private String[] getFronteiras() {
		return Fronteiras;
	}
	
	private void setFronteiras(String[] Front) {
		
		Fronteiras = new String[Front.length]; // Aloca��o de espa�o para vetor //
		for(int i=0; i < Front.length; i++) {  // 			Testar 				//
			Fronteiras[i]=Front[i];			
		}
	}
	
	
	
	
}
