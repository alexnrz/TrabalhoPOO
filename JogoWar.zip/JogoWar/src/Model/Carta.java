package Model;

class Carta {

}
