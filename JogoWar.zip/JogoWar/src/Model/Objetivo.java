package Model;

class Objetivo {

}
