package Model;
import javax.swing.JFrame;

import View.*;

// Alex Nascimento Rodrigues 
// Pedro de Aguiar Alves da Silva Menezes

public class Teste {

	public static void main(String[] args) {

		
		CxDefineQtdJog C = new CxDefineQtdJog("Informa��es dos Jogadores");
		C.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		C.setSize(400,100);
		C.setVisible(true);
		C.setLocationRelativeTo(null); // Centralizar //
		
	
		
	}

}
