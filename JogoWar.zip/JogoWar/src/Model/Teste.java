package Model;

import java.io.IOException;

import Controller.*;
import View.*;

// Alex Nascimento Rodrigues 
// Pedro de Aguiar Alves da Silva Menezes

public class Teste implements ObservadorIF {

	
	public static void main(String[] args) {	
		CxNovoJogo T = new CxNovoJogo();
		
		
		
	}

	@Override
	public void notify(Observado o) {
		// TODO Auto-generated method stub
		
	}


}
