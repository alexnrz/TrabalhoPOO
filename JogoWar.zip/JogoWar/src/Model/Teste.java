package Model;

public class Teste {

	public static void main(String[] args) {
		InicializaJogo a = new InicializaJogo();
		Acoes Act = new Acoes();
		Exercito [] E;
		Territorio[] T;
		Jogador[] J;
		
		a.inicializaTudo();		
		
		E = a.getListaExercitos();
		T = a.getListaTerritorios();
		J = a.getListaJogadores();
		
		System.out.println("Cor do Exercito: " + E[0].getCorExercito());
		System.out.println("Dono do exercito: " + E[0].getDonoExercito().getnomeJogador());
		System.out.println("QTD Unidades: " + E[0].getQTDExercito());
		
		System.out.println("Cor do Exercito: " + E[1].getCorExercito());
		System.out.println("Dono do exercito: " + E[1].getDonoExercito().getnomeJogador());
		System.out.println("QTD Unidades: " + E[1].getQTDExercito());
		
		System.out.println("Cor do Exercito: " + E[2].getCorExercito());
		System.out.println("Dono do exercito: " + E[2].getDonoExercito().getnomeJogador());
		System.out.println("QTD Unidades: " + E[2].getQTDExercito());		
		
		System.out.println("Dono do Territorio: " + T[0].getdonoTerritorio());
		System.out.println("Nome do Territorio: " + T[0].getNomeTerritorio());
		System.out.println("QTD Exercitos: " + T[0].getnumExercitos());
		System.out.println("Cor do Exercito no Territorio: " + T[0].getCorExercito());
		
		System.out.println("Dono do Territorio: " + T[1].getdonoTerritorio());
		System.out.println("Nome do Territorio: " + T[1].getNomeTerritorio());
		System.out.println("QTD Exercitos: " + T[1].getnumExercitos());
		System.out.println("Cor do Exercito no Territorio: " + T[1].getCorExercito());
		
		System.out.println("Dono do Territorio: " + T[2].getdonoTerritorio());
		System.out.println("Nome do Territorio: " + T[2].getNomeTerritorio());
		System.out.println("QTD Exercitos: " + T[2].getnumExercitos());
		System.out.println("Cor do Exercito no Territorio: " + T[2].getCorExercito());	
		
		
		Act.recebeExercitos(J,J[0].getnomeJogador(), T);
		
		
		
		
		
	}

}
