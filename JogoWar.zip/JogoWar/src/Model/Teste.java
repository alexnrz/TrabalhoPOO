package Model;

public class Teste {

	public static void main(String[] args) {
		InicializaJogo a = new InicializaJogo();
		
		a.inicializaTudo();

	}

}
