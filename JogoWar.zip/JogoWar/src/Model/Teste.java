package Model;

import Controller.*;
import View.*;

// Alex Nascimento Rodrigues 
// Pedro de Aguiar Alves da Silva Menezes

public class Teste {

	
	public static void main(String[] args) {	
		CxDefineQtdJog C = new CxDefineQtdJog();
	}

}
