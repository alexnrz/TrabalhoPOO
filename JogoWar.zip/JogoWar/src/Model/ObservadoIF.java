package Model;

public interface ObservadoIF {
	
	public void add(ObservadorIF o);
	public void remove(ObservadorIF o);
	
	public int get(int i);
	
	public String[] getNomesJogadores();
	public int getNumExercitos(String nomeTerritorio);
	public String getCorDonoTerritorio(String nomeTerritorio);
	
	public void setCores(String cor);
	public void setNomes(String nm);
	public void setQtdJogadores(int n);

}
