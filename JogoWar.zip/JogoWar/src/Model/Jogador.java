package Model;

class Jogador {

	private String Color;
	private String nomeJogador;
	private int numExercitos;
	private int numTerritoriosJog;
	private int ordemJogador;
	private Objetivo Ob;
	private Territorio Territorios[] = new Territorio[40];
	
	/* Fun��es referentes � cor do jogador */
	protected String getColor() {
		return Color;
	}	
	protected void setCor(String sColor) {
		Color = sColor;
	}	
	
	/* Fun��es referentes ao nome do jogador */
	protected String getnomeJogador() {
		return nomeJogador;
	}	
	protected void setnomeJogador(String nomeJ) {
		nomeJogador = nomeJ;
	}
	
	/* Fun��es referentes aos territ�rios do jogador */
	protected int getnumTerritoriosJog() {
		return numTerritoriosJog;
	}	
	protected void setnumTerritoriosJog(int num) {
		numTerritoriosJog = num;
	}	
	protected Territorio[] getListaTerritorios() {
		return Territorios;
	}
	protected void setUmTerritorio(Territorio T) {
		Territorios[getnumTerritoriosJog()]=T;
	}
	
	protected void retiraTerritorio(Territorio T) {
		
		for (int i=0;i<Territorios.length;i++) {
			if( T.getNomeTerritorio().contentEquals(Territorios[i].getNomeTerritorio())==true) {
				Territorios[i] =null;
				break;
			}
		}
	}
	
	
	/* Fun��es referentes aos ex�rcitos do jogador */
	protected void setNumExercitos(int n) {
		numExercitos = n;
	}
	protected int getNumExercitos() {
		return numExercitos;
	}
	
	
	
	/* Fun��es referentes � ordem do jogador */
	protected void setordemJogador (int num){
		ordemJogador =  num;
	}
	protected int getOrdemJogador() {
		return ordemJogador;
	}
	
	/* Fun��es referentes � ordem do jogador */
	protected void setObjetivo (Objetivo o){
		Ob = o;
	}	
	protected Objetivo getObjetivo ()
	{
		return Ob;
	}
}