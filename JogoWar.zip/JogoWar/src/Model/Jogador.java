package Model;

class Jogador {

	private String Color;
	private String nomeJogador;
	
	
	/* Fun��es referentes � cor do jogador */
	private String getColor() {
		return Color;
	}
	
	private void setCor(String sColor) {
		Color = sColor;
	}
	
	
	/* Fun��es referentes ao nome do jogador */
	private String getnomeJogador() {
		return nomeJogador;
	}
	
	private void setnomeJogador(String nomeJ) {
		nomeJogador = nomeJ;
	}
	
	
}
