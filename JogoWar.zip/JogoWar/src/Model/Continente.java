package Model;


class Continente {

	private String nomeContinente;
	private int numTerritorios;
	private Territorio []T;
	
	/* Nome Continente */
	private String getNomeContinente() {
		return nomeContinente;
	}
	protected void setNomeContinente(String nomeC) {
		nomeContinente = nomeC;
	}
	
	
	/* N�mero de Territ�rios no Continente */
	private int getNumTerritorios() {
		return numTerritorios;
	}
	protected void setNumTerritorios(int numT) {
		numTerritorios = numT;
	}
	
	/* Territ�rios presentes no Continente */
	private Territorio[] getTerritoriosContinente() {
		return T;
	}
	
	protected void setTerritoriosContinente(Territorio[] Territorios) {
		T = new Territorio[getNumTerritorios()]; // Aloca o vetor de territ�rios //
		
		for(int i=0; i < getNumTerritorios(); i++) {
			T[i] = Territorios[i];
		}
		
		
	}
	
	
	
	
	
	
}
