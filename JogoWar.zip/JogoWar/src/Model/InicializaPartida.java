package Model;
import java.util.Random;
import java.util.Scanner;


public class InicializaPartida {

	static int numeroDeTerritorios = 4; // N�mero de pa�ses //	
	static int numContinentes = 1;
	
	static Continente[] Continentes = new Continente[numContinentes];
	static Territorio[] listTerritorios;
	
	// Matriz onde o primeiro �ndice na primeira coluna 0 representa o pais, e o restante das colunas as suas fronteiras  //
	static String [][] paisesFronteiras = new String[numeroDeTerritorios+1][numeroDeTerritorios+1]; 
	
	static String []Paises = {"",
			"Brasil","Argentina","Peru","Venezuela"}; /// 1,2,3,4 //
	
	// Inicializa os territ�rios e suas fronteiras //
	public Territorio[] inicializaTerritorios() {
		
		// Lista com todo os territ�rios //
		listTerritorios = new Territorio[numeroDeTerritorios]; 
		
		
		for (int i=1; i <= numeroDeTerritorios;i++) {
			paisesFronteiras[i][0] = Paises[i];
		}
		
		/********* Am�rica do Sul ********/
		// Brasil [1][1] //
		paisesFronteiras[1][1] = null;			//	Brasil		// 
		paisesFronteiras[1][2] = Paises[2];		// 	Argentina	//
		paisesFronteiras[1][3] = Paises[3]; 	// 	Peru 		//
		paisesFronteiras[1][4] = null;			// 	Venezuela	//
		
		// Argentina  [2][2] //
		paisesFronteiras[2][1] = Paises[1];
		paisesFronteiras[2][3] = Paises[3];
		
		// Peru [3][3] //
		paisesFronteiras[3][1] = Paises[1];
		paisesFronteiras[3][2] = Paises[2]; 
		paisesFronteiras[3][4] = Paises[4];
		
		// Venezuela [4][4] //
		paisesFronteiras[4][1] = Paises[1];
		paisesFronteiras[4][3] = Paises[3];	

		
		
		for ( int i = 1; i <= numeroDeTerritorios; i++) {
			listTerritorios[i] = new Territorio(Paises[i],i,1,paisesFronteiras[i]);
		}		
		
		return listTerritorios;
		
	} 	

	
	public Continente[] defineContinentes(Territorio[] listaTerritorios) {
		
		Continente[] listaContinentes = new Continente[numContinentes];
		
		/* Am�rica do Sul */
		Territorio[] americaSul = new Territorio[4];		
		americaSul[0]=listaTerritorios[1];
		americaSul[1]=listaTerritorios[2];
		americaSul[2]=listaTerritorios[3];
		americaSul[3]=listaTerritorios[4];
		listaContinentes[0].setNomeContinente("America do Sul");
		listaContinentes[0].setNumTerritorios(4);
		listaContinentes[0].setTerritoriosContinente(americaSul);
		
		
		return listaContinentes;
		
	}
	
	
	
	// Define informa��es dos jogadores //
	public Jogador[] defineJogadores(int numJogadores) {
		Jogador[] listJogadores = new Jogador[numJogadores];
		
		String nomeJog;
		String corJog;
		Scanner Jog = new Scanner(System.in);
		
		for (int j =0; j < numJogadores; j++) {
			
			System.out.println("Digite o nome do jogador: ");
			nomeJog = Jog.next();
			for( int i = 0 ; i < numJogadores; i++) {
				if (listJogadores[i].getnomeJogador() == nomeJog) {
					System.out.println("Nome indispon�vel, digite outro nome:");
					nomeJog = Jog.next();
					i=0;
				}
			}
			
			System.out.println("Digite a cor do jogador"+nomeJog+":");
			corJog = Jog.next();			
			for( int i = 0 ; i < numJogadores; i++) {
				if (listJogadores[i].getColor() == corJog) {
					System.out.println("Cor indispon�vel, digite outra cor:");
					corJog = Jog.next();
					i=0;
				}
			}
			
			listJogadores[j].setCor(corJog);
			listJogadores[j].setnomeJogador(nomeJog);
		}
		
		Jog.close();
		return listJogadores;
	}
	
	
	
	// Define os donos territ�rios iniciais //
	public Territorio[] defineDonoTerritorios(int numJogadores) {
		Random gerador = new Random();
		Territorio[] listaTerritorios = inicializaTerritorios();
		Jogador[] listaJogadores = defineJogadores(numJogadores);
		int qtdTerritoriosPorJogador = numeroDeTerritorios/numJogadores;
		int cartasTerritorio;
		int jogAleatorio;
		
		for (int i=0; i < numeroDeTerritorios; i++) {
			
			// Gera um numero aleat�rio representando um territ�rio aleat�rio //
			cartasTerritorio = gerador.nextInt(numeroDeTerritorios);
			
			// Gera um numero aleatorio representando um jogador aleat�rio //
			jogAleatorio = gerador.nextInt(numJogadores);
			
			// Verifica se o territorio j� possui dono //
			while (listaTerritorios[cartasTerritorio].getdonoTerritorio() != null) {
				cartasTerritorio = gerador.nextInt(numeroDeTerritorios);
			}
			
			// Verifica se o jogador j� tem o m�ximo de territ�rios para iniciar //
			while (listaJogadores[jogAleatorio].getnumTerritoriosJog() > qtdTerritoriosPorJogador) {
				jogAleatorio = gerador.nextInt(numJogadores);
			}
			
			
			listaTerritorios[cartasTerritorio].setdonoTerritorio(listaJogadores[jogAleatorio].getnomeJogador());
			listaJogadores[jogAleatorio].setnumTerritoriosJog(listaJogadores[jogAleatorio].getnumTerritoriosJog()+1);
			
			
		}	
		
		return listaTerritorios;
	}
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	

