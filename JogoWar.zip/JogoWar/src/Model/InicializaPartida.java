package Model;
import java.util.Random;
import java.util.Scanner;


public class InicializaPartida {

	static int numeroDeTerritorios = 4; // N�mero de pa�ses //	
	
	
	static Territorio[] listTerritorios;
	
	// Matriz onde o primeiro �ndice na primeira coluna 0 representa o pais, e o restante das colunas as suas fronteiras  //
	static String [][] paisesFronteiras = new String[numeroDeTerritorios][numeroDeTerritorios+1]; 
	
	static String []Paises = {"Brasil","Chile", "Argentina", "Uruguai"};
	
	// Inicializa os territ�rios e suas fronteiras //
	public static Territorio[] inicializaTerritorios() {
		
		listTerritorios = new Territorio[3]; // Lista com todo os territ�rios //
		
		for (int i=0; i < numeroDeTerritorios;i++) {
			paisesFronteiras[i][0] = Paises[i];
		}
		
		// Brasil 0 //
		paisesFronteiras[0][1] = null;
		paisesFronteiras[0][2] = null;
		paisesFronteiras[0][3] = Paises[3];
		paisesFronteiras[0][4] = Paises[4];
		
		
		// Chile  1 //
		paisesFronteiras[1][1] = null;
		paisesFronteiras[1][2] = null;
		paisesFronteiras[1][3] = Paises[3];
		paisesFronteiras[1][4] = null;
		
		// Argentina 2 //
		paisesFronteiras[2][1] = Paises[1];
		paisesFronteiras[2][2] = null;
		paisesFronteiras[2][3] = Paises[3];
		paisesFronteiras[2][4] = Paises[4];
		
		// Uruguai 3 //
		paisesFronteiras[3][1] = Paises[1];
		paisesFronteiras[3][2] = null;
		paisesFronteiras[3][3] = Paises[3];
		paisesFronteiras[3][3] = null;		
		
		for ( int i = 0; i < numeroDeTerritorios; i++) {
			listTerritorios[i] = new Territorio(Paises[0],i+1,1,paisesFronteiras[i]);
		}		
		
		return listTerritorios;
		
	} 	
	
	// Define informa��es dos jogadores //
	public Jogador[] defineJogadores(int numJogadores) {
		Jogador[] listJogadores = new Jogador[numJogadores];
		int i=1;
		Scanner nomeJog = new Scanner(System.in);
		
		for (int j =0; j < numJogadores; j++) {
			
			
			System.out.println("Digite a cor do jogador"+i+":");
			
		}
		
		
		return listJogadores;
	}
	
	
	
	// Define os donos territ�rios iniciais //
	public Territorio[] defineDonoTerritorios(int numJogadores, Jogador[] listaJogadores) {
		Random gerador = new Random();
		Territorio[] listaTerritorios = inicializaTerritorios();
		int qtdTerritoriosPorJogador = numeroDeTerritorios/numJogadores;
		int cartasTerritorio;
		int jogAleatorio;
		
		for (int i=0; i < numeroDeTerritorios; i++) {
			
			// Gera um numero aleat�rio representando um territ�rio aleat�rio //
			cartasTerritorio = gerador.nextInt(numeroDeTerritorios);
			
			// Gera um numero aleatorio representando um jogador aleat�rio //
			jogAleatorio = gerador.nextInt(numJogadores);
			
			// Verifica se o territorio j� possui dono //
			while (listaTerritorios[cartasTerritorio].getdonoTerritorio() != null) {
				cartasTerritorio = gerador.nextInt(numeroDeTerritorios);
			}
			
			// Verifica se o jogador j� tem o m�ximo de territ�rios para iniciar //
			while (listaJogadores[jogAleatorio].getnumTerritoriosJog() > qtdTerritoriosPorJogador) {
				jogAleatorio = gerador.nextInt(numJogadores);
			}
			
			
			listaTerritorios[cartasTerritorio].setdonoTerritorio(listaJogadores[jogAleatorio].getnomeJogador());
			listaJogadores[jogAleatorio].setnumTerritoriosJog(listaJogadores[jogAleatorio].getnumTerritoriosJog()+1);
			
			
		}	
		return listaTerritorios;
	}
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	

