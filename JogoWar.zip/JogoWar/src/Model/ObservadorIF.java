package Model;

public interface ObservadorIF {
	
	public void add(ObservadorIF o);
	public void remove(ObservadorIF o);
	public int get(int i);
	public void not(ObservadoIF o);
	

}
