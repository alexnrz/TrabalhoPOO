package View;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;

import Controller.Inicializa;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CxDefineInfoJog extends JFrame {
	
	private JTextField caixaNome[], caixaCor[];
	private JButton Enviar = new JButton("Enviar");
	private JLabel lbNomeJog,lbCorJog;
	
	public CxDefineInfoJog(int qtd) {
		super("Informa��es dos Jogadores");
		 
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,85*qtd);
		setLocationRelativeTo(null);
		
		caixaNome = new JTextField[qtd];
		caixaCor = new JTextField[qtd];	
			
		for( int i=0; i < qtd;i++) {	
			lbNomeJog = new JLabel("Nome do Jogador "+(i+1)+": ");		
			add(lbNomeJog);
			
			caixaNome[i] = new JTextField(20);
			add(caixaNome[i]);
			lbCorJog = new JLabel("Cor do Jogador "+(i+1)+":     ");
			add(lbCorJog);
			
			caixaCor[i] = new JTextField(20);
			add(caixaCor[i]);
		}
	
		Enviar.addActionListener((ActionEvent e) -> 
				enviarNomeCor(qtd)
		);
		add(Enviar);
		
	}
	
	private void enviarNomeCor(int qtd) {
		
		for(int i=0; i < qtd; i++) {
			Inicializa.getInicicializa().setNomes(caixaNome[i].getText());
			Inicializa.getInicicializa().setCores(caixaCor[i].getText());
		}
		
		Inicializa.getInicicializa().inicializaPartida();
		
		dispose();
	}
	
}
