package View;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;

import Controller.Inicializa;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CxDefineInfoJog extends JFrame {
	
	private JTextField caixaNome, caixaCor;
	private JButton Enviar = new JButton("Enviar");
	private JLabel lbNomeJog,lbCorJog;
	private String nomeJog, corJog;
	
	public CxDefineInfoJog(int qtd) {
		super("Informa��es dos Jogadores");
		
		
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,85*qtd);
		setLocationRelativeTo(null);
		
		for (int i=0; i < qtd;i++) {
			lbNomeJog = new JLabel("Nome do Jogador "+(i+1)+": ");		
			add(lbNomeJog);
			
			caixaNome = new JTextField(20);
			nomeJog = caixaNome.getText();
			Inicializa.getInicicializa().setNomes(nomeJog);
			add(caixaNome);
			
			lbCorJog = new JLabel("Cor do Jogador "+(i+1)+":     ");
			add(lbCorJog);
			
			caixaCor = new JTextField(20);
			corJog = caixaCor.getText();
			Inicializa.getInicicializa().setCores(corJog);
			add(caixaCor);
		}
		
		Enviar.addActionListener((ActionEvent e) -> Inicializa.getInicicializa().inicializaPartida()
				);
		add(Enviar);
		
		
		
	}
}
