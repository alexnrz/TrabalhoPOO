package View;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CxDefineInfoJog extends JFrame {
	
	private JTextField caixaNome, caixaCor;
	private JButton Enviar = new JButton("Enviar");
	private JLabel nomeJog,corJog;
	
	
	public CxDefineInfoJog(String nomeJogador, String corJogador, int qtd) {
		super("Informa��es dos Jogadores");
		
		
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,150);
		setLocationRelativeTo(null);
		nomeJog = new JLabel("Nome do Jogador: ");		
		add(nomeJog);
		caixaNome = new JTextField(20);
		nomeJogador = caixaNome.getText();
		add(caixaNome);
		
		corJog = new JLabel("Cor do Jogador:     ");
		add(corJog);
		caixaCor = new JTextField(20);
		corJogador = caixaCor.getText();
		add(caixaCor);
		Enviar.addActionListener((ActionEvent e) -> 
		dispose()
				);
		add(Enviar);
		
		
		
	}
}
