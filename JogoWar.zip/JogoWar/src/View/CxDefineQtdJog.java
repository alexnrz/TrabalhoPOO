package View;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import Controller.Inicializa;

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.IOException;


// Alterar para n�o deixar p�blico ///
public class CxDefineQtdJog extends JFrame {
	
	private JTextField caixa;
	private JButton Enviar = new JButton("Enviar");
	private JLabel qtdJogador;	
	
	public CxDefineQtdJog() {
		super("Informa��es dos Jogadores");
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,100);
		
		setLocationRelativeTo(null);
		
		qtdJogador = new JLabel("Quantidade de Jogadores:");		
		add(qtdJogador);
		caixa = new JTextField(20);
		add(caixa);
		Enviar.addActionListener((ActionEvent e) -> abrirNovoFrame(Integer.parseInt(caixa.getText())));
		setVisible(true);
		add(Enviar);		
	}

    private void abrirNovoFrame(int qtdJog) {
    	Inicializa.getInicicializa().setQtdJogadores(qtdJog);
    	
    	SwingUtilities.invokeLater(() -> { new CxDefineInfoJog(qtdJog).setVisible(true); });    	
    	
    	dispose();
    }	
    
	
	
}
