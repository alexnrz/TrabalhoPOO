package View;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import Controller.Inicializa;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;


// Alterar para n�o deixar p�blico ///
public class CxDefineQtdJog extends JFrame {
	
	private JTextField caixa;
	private JButton Enviar = new JButton("Enviar");
	private JLabel qtdJogador;
	
	public CxDefineQtdJog(String name) {
		super(name);
		setLayout(new FlowLayout());
		qtdJogador = new JLabel("Quantidade de Jogadores:");		
		add(qtdJogador);
		caixa = new JTextField(20);
		add(caixa);
		Enviar.addActionListener((ActionEvent e) -> abrirNovoFrame(Integer.parseInt(caixa.getText())));
		
		add(Enviar);		
	}

    private void abrirNovoFrame(int qtdJog) {
    	String []nomeJogador = new String[qtdJog];
    	String []corJogador = new String[qtdJog];
    	String nome = new String();
    	String cor = new String();
    	int i;    	
    	
    	Inicializa.getInicicializa().setQtdJogadores(qtdJog);
    	for ( i=0; i< qtdJog;i++) {
    		SwingUtilities.invokeLater(() -> { new CxDefineInfoJog(qtdJog).setVisible(true); });
    	}
    	
    }
	
	
	
}
