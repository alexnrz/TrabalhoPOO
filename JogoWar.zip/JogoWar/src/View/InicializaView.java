package View;

public class InicializaView {
	
	
	
	
	private static InicializaView ctrl = null;
	
	private InicializaView(){}
	
	public static InicializaView getInicializaView() {
		if(ctrl == null) {
			ctrl = new InicializaView();
		}
		return ctrl;
	}
	
	
	
	
	
	
	
	public void inicilizaInfosIniciais() {
		
		
		
	}
	

}
