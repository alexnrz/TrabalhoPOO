package View;

import Controller.ControlaJogo;

public class ControlaView {
	
	int qtdJogadores;
	
	
	private static ControlaView ctrl = null;
	
	private int qtdEx;
	private int faseCtrl = 0;
	private int jogAlvoCtrl  =0;
	private int qtdExAtk;
	private int qtdExDef;
	private String corAtk;
	private String territorioAtacante;
	private String territorioDefensor;
	
	private ControlaView(){}
	
	public static ControlaView getInicializaView() {
		if(ctrl == null) {
			ctrl = new ControlaView();
		}
		return ctrl;
	}
	
	public void iniciaPartida() {
		new CxNovoJogo();
	}


	public void inicilizaInfosIniciais() {

		
		
		new CxDefineQtdJog();
		
		
	}
	
	public void  inicializaTabuleiro() {
		CxTabuleiro.getCxTabuleiro();	
		// Tirar //
		
		//	//	//
		
		new CxObjetivos(qtdJogadores);
		inicializaControleJogadas(1,ControlaJogo.getControlaJogo().getJogDaVez());
	}
	
	public void inicializaControleJogadas(int fase,int jogAlvo) {
		
		// Fase de Receber e posicionar Ex�rcitos //		
		if(fase == 1) {
			
			CxProxJogada.getCxProxJogada(fase, jogAlvo);
		}
		// Ataque //
		if(fase == 2) {
			CxProxJogada.getCxProxJogada(fase, jogAlvo);
		}
		
		// Fase de ataque //
		if(fase == 4) {
			CxProxJogada.getCxProxJogada(fase, jogAlvo);
		}
		
	}
	
	public void setQtdJogadores(int qtd) {
		qtdJogadores = qtd;
	}
	
	public void setQtdEx(int n) {
		qtdEx= n;
	}
	public int getQtdEx() {
		return qtdEx;
	}
	public int getFaseCtrl() {
		return faseCtrl;
	}
	public void setFaseJogada(int n) {
		faseCtrl = n;
	}
	public int getJogAlvo() {
		return jogAlvoCtrl;
	}
	public void setTerritorioAtk(String atk) {
		territorioAtacante = atk;
	}
	public String getTerritorioAtk() {
		return territorioAtacante;
	}
	public void setTerritorioDef(String def) {
		territorioDefensor = def;
	}
	public String getTerritorioDef() {
		return territorioDefensor;
	}
	public String getCorAtk() {
		return corAtk;
	}
	public void setCorAtk(String cor) {
		corAtk = cor;
	}
	
	
	public void setQtdExAtk(int n) {
		qtdExAtk = n;
	}
	public int getQtdExAtk() {
		return qtdExAtk;
	}
	public void setQtdExDef(int n) {
		qtdExDef = n;
	}
	public int getQtdExDef() {
		return qtdExDef;
	}
	
	
}
