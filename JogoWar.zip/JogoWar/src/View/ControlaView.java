package View;

import Controller.ControlaJogo;

public class ControlaView {
	
	int qtdJogadores;
	
	
	private static ControlaView ctrl = null;
	private int qtdEx;
	
	private ControlaView(){}
	
	public static ControlaView getInicializaView() {
		if(ctrl == null) {
			ctrl = new ControlaView();
		}
		return ctrl;
	}
	
	public void iniciaPartida() {
		new CxNovoJogo();
	}


	public void inicilizaInfosIniciais() {

		
		
		new CxDefineQtdJog();
		
		
	}
	
	public void  inicializaTabuleiro() {
		new CxTabuleiro();		
		new CxExibeDadosAtaque(3,2);
		new CxObjetivos(qtdJogadores);
		inicializaControleJogadas(1,ControlaJogo.getControlaJogo().getJogDaVez());
	}
	
	public void inicializaControleJogadas(int fase,int jogAlvo) {
		// Fase de Receber Ex�rcitos //
		if(fase == 1 || fase ==2) {
			new CxProxJogada(fase,jogAlvo);
		}
		if(fase == 3) {
			new CxProxJogada(fase,jogAlvo);
		}
		if(fase == 4) {
			new CxProxJogada(fase,jogAlvo);
		}
		
	}
	
	public void setQtdJogadores(int qtd) {
		qtdJogadores = qtd;
	}
	
	public void setQtdEx(int n) {
		qtdEx= n;
	}
	public int getQtdEx() {
		return qtdEx;
	}
	
	

}
