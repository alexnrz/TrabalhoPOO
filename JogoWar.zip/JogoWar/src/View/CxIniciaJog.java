package View;
import Model.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
public class CxIniciaJog extends JFrame {
	JButton Comecar = new JButton("Come�ar");
	
	public CxIniciaJog(String[] Nomes,String[] Cores) {
		super("In�cio do Jogo");
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,150);
		setLocationRelativeTo(null);
		setVisible(true);
		Acoes A = new Acoes();
		
		Comecar.addActionListener((ActionEvent e) -> A.inicializaJogo(Nomes, Cores) );
		
		add(Comecar);
		
	}

}
