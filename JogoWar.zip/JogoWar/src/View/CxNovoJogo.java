package View;

import java.awt.*;
import java.net.*;
import javax.swing.*;

public class CxNovoJogo extends JFrame {

	private static final long serialVersionUID = 1L;

	private String imgMenu = "/Img/bgconfiguracao.png";
	private JButton btnJogar;

	public CxNovoJogo() {
		// utilize como container um painel pr�prio para renderizar uma imagem de fundo
		ImagePanel imagePanel = new ImagePanel(imgMenu);
		this.setContentPane(imagePanel);

		this.setTitle("Novo Jogo");
		this.setSize(410, 685);
		this.setLocationRelativeTo(null);
		this.setLayout(null);

		btnJogar = new JButton("");
		btnJogar.setBounds(0, 0, 100, 30);
		btnJogar.setOpaque(false);
		btnJogar.setContentAreaFilled(false);
		btnJogar.setBorderPainted(false);

		btnJogar.addActionListener(event -> pressionouBtnJogar());

		JPanel painel = new JPanel();
		painel.setOpaque(false); // o container do bot�o tamb�m tem que ser transparente
		painel.setLayout(new GridLayout(1, 1));
		painel.setBounds(0, 55, 235, 45);
		painel.add(btnJogar);

		this.add(painel);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);

	}

	private void pressionouBtnJogar() {
		CxDefineQtdJog C = new CxDefineQtdJog();
		dispose();
	}
}




