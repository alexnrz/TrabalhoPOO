package View;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

class CxPosicionaExercitos extends JFrame {

	private static JFrame frame = new JFrame();
	private static JLabel labelQtd = new JLabel();
	private JRadioButton[] lstButtons;
	private ButtonGroup bg = new ButtonGroup();
	private static int totalEx = -1;
	
	private static CxPosicionaExercitos ctrl =null;
	
	public static CxPosicionaExercitos getCxPosicionaExercitos(int Ex, String[] listaTerritorios) {
		frame.repaint();
		frame.validate();
		frame.setVisible(true);
		if (totalEx ==-1) {
			totalEx=Ex;
		}
		else {
			totalEx = totalEx-Ex;
		}
		
		if(ctrl==null) {
			
			
			labelQtd = new JLabel();
			frame.add(labelQtd);
			ctrl = new CxPosicionaExercitos( listaTerritorios);
		}
		if (totalEx == 0) {
			 JOptionPane.showMessageDialog(null,"N�o h� ex�rcitos para posicionar"); 
			 //
			 
			 frame.dispose();
		}
		labelQtd.setText("Quantidade dispon�vel: "+totalEx );
		labelQtd.setBounds(0, 0, 150, 25);
		
		
		System.out.println("TOTAL EX: "+totalEx);
		return ctrl;
	}
			
	private CxPosicionaExercitos (String[] listaTerritorios) {
		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Posicionamento dos Ex�rcitos");
		frame.setSize(250,20*listaTerritorios.length);		
		frame.setLocationRelativeTo(null);
		frame.repaint();
		frame.validate();
		
		
		lstButtons = new JRadioButton[listaTerritorios.length];
		
		for (int i=0;i<listaTerritorios.length;i++) {
			lstButtons[i] = new JRadioButton();
			lstButtons[i].setText(listaTerritorios[i]);
			lstButtons[i].setSize(100, 30);
			lstButtons[i].addMouseListener(getMouseListener(totalEx ,listaTerritorios[i],listaTerritorios));
			bg.add(lstButtons[i]);
			frame.add(lstButtons[i],BorderLayout.CENTER);
			
		}
		
		frame.setVisible(true);		
		
	}
	//JOptionPane.showMessageDialog(null,"Quantidade indispon�vel"); 
	
	private static MouseListener getMouseListener(int qtdEx,String territorioAlvo,String[] listaTerritorios)	{
			return new MouseAdapter()
			{
				@Override			
				public void mouseClicked( MouseEvent e )
				{
					new CxDefineQtdExercitos(qtdEx,territorioAlvo,listaTerritorios);
					frame.repaint();
					frame.validate();
					
				}
			};
	}

	
					
}



