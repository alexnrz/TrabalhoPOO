package View;
import java.awt.Insets;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Model.Acoes;

public class CxExibeObjetivos extends JFrame{
	
	
	private String imgObjetivo = "Img/war_carta_objetivo_grande.png";
	private JButton[] exibeObjetivo;
	
	public CxExibeObjetivos(int qtdJogador) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Objetivos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		BoxLayout boxlayout = new BoxLayout(panel,BoxLayout.Y_AXIS);
		panel.setLayout(boxlayout);
		String nomes[] = new String[qtdJogador];
		nomes = Acoes.getAcoes().getNomesJogadores();		
		
		frame.setLocation(1472, 135);
		exibeObjetivo = new JButton[qtdJogador];
		
		for ( int i=0; i < qtdJogador;i++) {
			
			exibeObjetivo[i] = new JButton("Objetivos do Jogador "+nomes[i]);
			panel.add(exibeObjetivo[i]);
		}
		
		
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
		
	}
	

}
