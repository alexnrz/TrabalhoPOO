package View;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import Controller.Inicializa;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;

public class CxExibeObjetivos extends JFrame{

}
