package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import Model.Acoes;

public class CxExibeObjetivo extends JFrame {
	
	private String imgObjetivo = "/Img/war_carta_objetivo_grande.png";
	private String[] obj;
	
	public CxExibeObjetivo(String nomeJogador)  {
		
		ImagePanel imagePanel1= new ImagePanel(imgObjetivo);
		this.setContentPane(imagePanel1);
		this.setTitle("Carta Objetivo");
		this.setSize(353,581);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setVisible(true);
		
		JTextArea textArea = new JTextArea();
		
		textArea.setSize(297,340);
		textArea.setLocation(23, 108);
		textArea.setEditable(false);
		textArea.setBackground(new Color(1,1,1,0));
	   // textArea.setLineWrap(true);
	    //textArea.setWrapStyleWord(true);
		obj = Acoes.getAcoes().getObjetivosJogador(nomeJogador);
		
		if(obj[0] == null) {
			obj[0] = "N�o necess�rio";
		}
		if(obj[1] == null) {
			obj[1] = "qualquer quantidade de";
		}
		if(obj[2] == null) {
			obj[2] = "N�o necess�rio";
		}
		
		textArea.setText("\n\n Destruir o Ex�rcito: "+obj[0]+"\n"
						 +" Possuir "+obj[1]+" Territ�rios no total\n"
						 +" Conquistar os Continentes: "+obj[2]+"\n"
						 );
		this.add(textArea);
		this.setResizable(false);
		///this.setDefaultCloseOperation(3); // TIRAR //
		
		
		
		
		
		
		
	}
	

}
