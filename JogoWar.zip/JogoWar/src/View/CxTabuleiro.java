package View;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Model.Acoes;

@SuppressWarnings("serial")
public class CxTabuleiro extends JFrame{
	
	private String imgTerritorios = "/Img/war_tabuleiro_mapa.png";
	
	
	public CxTabuleiro() {
		
		ImagePanel imagePanel2 = new ImagePanel(imgTerritorios);
		this.setContentPane(imagePanel2);
		this.setTitle("Tabuleiro");
		this.setSize(1024,768);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		
		
		/////// ALASCA /////////
		JPanel Alasca = new JPanel();
		Alasca.setName( "Alasca" );
		Alasca.setBackground( Color.RED );
	//	Alasca.setOpaque(false); // Deixa invisivel //
		Alasca.setLayout(new GridLayout(1, 1));
		Alasca.setBounds( 70, 115, 40, 40 );
		Alasca.addMouseListener( getMouseListener() );
		
		this.add(Alasca);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// CALGARY /////////
		JPanel Calgary = new JPanel();
		Calgary.setName( "Calgary" );
		// para teste
		Calgary.setBackground( Color.RED );
	//	Calgary.setOpaque(false); // Deixa invisivel //
		Calgary.setLayout(new GridLayout(1, 1));
		Calgary.setBounds( 150, 110, 100, 50 );
		Calgary.addMouseListener( getMouseListener() );
		
		this.add(Calgary);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// GROELANDIA /////////
		JPanel Groelandia = new JPanel();
		Groelandia.setName( "Groelandia" );
		// para teste
		Groelandia.setBackground( Color.RED );
	//	California.setOpaque(false); // Deixa invisivel //
		Groelandia.setLayout(new GridLayout(1, 1));
		Groelandia.setBounds( 270, 85, 100, 45 );
		Groelandia.addMouseListener( getMouseListener() );
		
		this.add(Groelandia);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// VANCOUVER /////////
		JPanel Vancouver = new JPanel();
		Vancouver.setName( "Vancouver" );
		// para teste
		Vancouver.setBackground( Color.RED );
	//	Vancouver.setOpaque(false); // Deixa invisivel //
		Vancouver.setLayout(new GridLayout(1, 1));
		Vancouver.setBounds( 110, 165, 100, 40 );
		Vancouver.addMouseListener( getMouseListener() );
		
		this.add(Vancouver);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// QUEBEC /////////
		JPanel Quebec = new JPanel();
		Quebec.setName( "Quebec" );
		// para teste
		Quebec.setBackground( Color.RED );
	//	Quebec.setOpaque(false); // Deixa invisivel //
		Quebec.setLayout(new GridLayout(1, 1));
		Quebec.setBounds( 225, 165, 90, 40 );
		Quebec.addMouseListener( getMouseListener() );
		
		this.add(Quebec);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		
		/////// CALIFORNIA /////////
		JPanel California = new JPanel();
		California.setName( "California" );
		// para teste
		California.setBackground( Color.RED );
	//	California.setOpaque(false); // Deixa invisivel //
		California.setLayout(new GridLayout(1, 1));
		California.setBounds( 90, 210, 45, 80 );
		California.addMouseListener( getMouseListener() );		
		
		this.add(California);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// TEXAS /////////
		JPanel Texas = new JPanel();
		Texas.setName( "Texas" );
		Texas.setBackground( Color.RED );
	//	Texas.setOpaque(false); // Deixa invisivel //
		Texas.setLayout(new GridLayout(1, 1));
		Texas.setBounds( 150, 210, 35, 80 );
		Texas.addMouseListener( getMouseListener() );		
		
		this.add(Texas);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// NOVA YORK /////////
		JPanel NovaYork = new JPanel();
		NovaYork.setName( "Nova York" );
		NovaYork.setBackground( Color.RED );
	//	NovaYork.setOpaque(false); // Deixa invisivel //
		NovaYork.setLayout(new GridLayout(1, 1));
		NovaYork.setBounds( 200, 210, 85, 80 );
		NovaYork.addMouseListener( getMouseListener() );		
		
		this.add(NovaYork);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		/////// MEXICO /////////
		JPanel Mexico = new JPanel();
		Mexico.setName( "Mexico" );
		Mexico.setBackground( Color.RED );
	//	Mexico.setOpaque(false); // Deixa invisivel //
		Mexico.setLayout(new GridLayout(1, 1));
		Mexico.setBounds( 135, 320, 50, 70 );
		Mexico.addMouseListener( getMouseListener() );		
		
		this.add(Mexico);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		//////////////
		//// Am�rica do Sul ////////
		///////
		
		/////// VENEZUELA /////////
		JPanel Venezuela = new JPanel();
		Venezuela.setName( "Venezuela" );
		Venezuela.setBackground( Color.GREEN );
	//	Venezuela.setOpaque(false); // Deixa invisivel //
		Venezuela.setLayout(new GridLayout(1, 1));
		Venezuela.setBounds( 170, 390, 50, 50 );
		Venezuela.addMouseListener( getMouseListener() );		
		
		this.add(Venezuela);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		
		/////// PERU /////////
		JPanel Peru = new JPanel();
		Peru.setName( "Peru" );
		Peru.setBackground( Color.GREEN );
	//	Peru.setOpaque(false); // Deixa invisivel //
		Peru.setLayout(new GridLayout(1, 1));
		Peru.setBounds( 210, 440, 50, 50 );
		Peru.addMouseListener( getMouseListener() );		
		
		this.add(Peru);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		
		/////// ARGENTINA /////////
		JPanel Argentina = new JPanel();
		Argentina.setName( "Argentina" );
		Argentina.setBackground( Color.GREEN );
	//	Argentina.setOpaque(false); // Deixa invisivel //
		Argentina.setLayout(new GridLayout(1, 1));
		Argentina.setBounds( 260, 480, 60, 100 );
		Argentina.addMouseListener( getMouseListener() );		
		
		this.add(Argentina);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		
		
		/////// BRASIL /////////
		JPanel Brasil = new JPanel();
		Brasil.setName( "Brasil" );
		Brasil.setBackground( Color.GREEN );
	//	Brasil.setOpaque(false); // Deixa invisivel //
		Brasil.setLayout(new GridLayout(1, 1));
		Brasil.setBounds( 265, 390, 65, 85 );
		Brasil.addMouseListener( getMouseListener() );		
		
		this.add(Brasil);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(3);
		//////////////


		
		
	}

	private static MouseListener getMouseListener()
	{
		return new MouseAdapter()
		{
			@Override
			public void mouseClicked( MouseEvent e )
			{
				
				System.out.println( ( ( JComponent ) e.getSource() ).getName() );
				int qtdExercitos = Acoes.getAcoes().getNumExercitos(( ( JComponent ) e.getSource() ).getName());
				
				
				
				String dono = Acoes.getAcoes().getCorDonoTerritorio( ( ( JComponent ) e.getSource() ).getName() );
				
				String msg = "Quantidade de Ex�rcitos: "+qtdExercitos+"\nCor do Dono: "+dono;
				JOptionPane.showMessageDialog(null, msg,( ( JComponent ) e.getSource() ).getName(),JOptionPane.INFORMATION_MESSAGE); 
				
				
			}
		};
	}

}
