package View;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Controller.ControlaJogo;
import Model.*;

// Observer e Singleton implementados //
public class CxTabuleiro extends JFrame implements ObservadorIF{
	
	private String imgTerritorios = "/Img/war_tabuleiro_mapa.png";
	private static String corJog;
	private static CxTabuleiro ctrl = null;
	
	
	public static CxTabuleiro getCxTabuleiro() {
		if( ctrl == null) {
			ctrl = new CxTabuleiro();
		}
		
		return ctrl;
	}
	
	public CxTabuleiro() {
		
		ImagePanel imagePanel1 = new ImagePanel(imgTerritorios);
		this.setContentPane(imagePanel1);
		this.setTitle("Tabuleiro");
		this.setSize(1024,768);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		
		////////////////////////////
		////////Am�rica do Norte////
		////////////////////////////
		/////// ALASCA /////////
		JPanel Alasca = new JPanel();
		Alasca.setName( "Alasca" );
		Alasca.setBackground( Color.RED );
		Alasca.setOpaque(false); // Deixa invisivel //
		Alasca.setLayout(new GridLayout(1, 1));
		Alasca.setBounds( 70, 115, 40, 40 );
		Alasca.addMouseListener( getMouseListener() );
		
		this.add(Alasca);
		
		/////// CALGARY /////////
		JPanel Calgary = new JPanel();
		Calgary.setName( "Calgary" );
		Calgary.setBackground( Color.RED );
		Calgary.setOpaque(false); // Deixa invisivel //
		Calgary.setLayout(new GridLayout(1, 1));
		Calgary.setBounds( 150, 110, 100, 50 );
		Calgary.addMouseListener( getMouseListener() );
		
		this.add(Calgary);
		
		/////// GROELANDIA /////////
		JPanel Groelandia = new JPanel();
		Groelandia.setName( "Groelandia" );
		Groelandia.setBackground( Color.RED );
		Groelandia.setOpaque(false); // Deixa invisivel //
		Groelandia.setLayout(new GridLayout(1, 1));
		Groelandia.setBounds( 270, 85, 100, 45 );
		Groelandia.addMouseListener( getMouseListener() );
		
		this.add(Groelandia);
		
		/////// VANCOUVER /////////
		JPanel Vancouver = new JPanel();
		Vancouver.setName( "Vancouver" );
		Vancouver.setBackground( Color.RED );
		Vancouver.setOpaque(false); // Deixa invisivel //
		Vancouver.setLayout(new GridLayout(1, 1));
		Vancouver.setBounds( 110, 165, 100, 40 );
		Vancouver.addMouseListener( getMouseListener() );
		
		this.add(Vancouver);
		
		/////// QUEBEC /////////
		JPanel Quebec = new JPanel();
		Quebec.setName( "Quebec" );
		// para teste
		Quebec.setBackground( Color.RED );
		Quebec.setOpaque(false); // Deixa invisivel //
		Quebec.setLayout(new GridLayout(1, 1));
		Quebec.setBounds( 225, 165, 90, 40 );
		Quebec.addMouseListener( getMouseListener() );
		
		this.add(Quebec);
		
		
		/////// CALIFORNIA /////////
		JPanel California = new JPanel();
		California.setName( "California" );
		// para teste
		California.setBackground( Color.RED );
		California.setOpaque(false); // Deixa invisivel //
		California.setLayout(new GridLayout(1, 1));
		California.setBounds( 90, 210, 45, 80 );
		California.addMouseListener( getMouseListener() );		
		
		this.add(California);
		
		/////// TEXAS /////////
		JPanel Texas = new JPanel();
		Texas.setName( "Texas" );
		Texas.setBackground( Color.RED );
		Texas.setOpaque(false); // Deixa invisivel //
		Texas.setLayout(new GridLayout(1, 1));
		Texas.setBounds( 150, 210, 35, 80 );
		Texas.addMouseListener( getMouseListener() );		
		
		this.add(Texas);
		
		/////// NOVA YORK /////////
		JPanel NovaYork = new JPanel();
		NovaYork.setName( "Nova York" );
		NovaYork.setBackground( Color.RED );
		NovaYork.setOpaque(false); // Deixa invisivel //
		NovaYork.setLayout(new GridLayout(1, 1));
		NovaYork.setBounds( 200, 210, 85, 80 );
		NovaYork.addMouseListener( getMouseListener() );		
		
		this.add(NovaYork);
		this.setDefaultCloseOperation(3);
		
		/////// MEXICO /////////
		JPanel Mexico = new JPanel();
		Mexico.setName( "Mexico" );
		Mexico.setBackground( Color.RED );
		Mexico.setOpaque(false); // Deixa invisivel //
		Mexico.setLayout(new GridLayout(1, 1));
		Mexico.setBounds( 135, 320, 50, 70 );
		Mexico.addMouseListener( getMouseListener() );		
		
		this.add(Mexico);
		
		////////////////////////////
		////////Am�rica do Sul//////
		////////////////////////////
		
		/////// VENEZUELA /////////
		JPanel Venezuela = new JPanel();
		Venezuela.setName( "Venezuela" );
		Venezuela.setBackground( Color.GREEN );
		Venezuela.setOpaque(false); // Deixa invisivel //
		Venezuela.setLayout(new GridLayout(1, 1));
		Venezuela.setBounds( 170, 390, 50, 50 );
		Venezuela.addMouseListener( getMouseListener() );		
		
		this.add(Venezuela);
		
		
		/////// PERU /////////
		JPanel Peru = new JPanel();
		Peru.setName( "Peru" );
		Peru.setBackground( Color.GREEN );
		Peru.setOpaque(false); // Deixa invisivel //
		Peru.setLayout(new GridLayout(1, 1));
		Peru.setBounds( 210, 440, 50, 50 );
		Peru.addMouseListener( getMouseListener() );		
		
		this.add(Peru);
		
		
		/////// ARGENTINA /////////
		JPanel Argentina = new JPanel();
		Argentina.setName( "Argentina" );
		Argentina.setBackground( Color.GREEN );
		Argentina.setOpaque(false); // Deixa invisivel //
		Argentina.setLayout(new GridLayout(1, 1));
		Argentina.setBounds( 260, 480, 60, 100 );
		Argentina.addMouseListener( getMouseListener() );		
		
		this.add(Argentina);
		
		
		/////// BRASIL /////////
		JPanel Brasil = new JPanel();
		Brasil.setName( "Brasil" );
		Brasil.setBackground( Color.GREEN );
		Brasil.setOpaque(false); // Deixa invisivel //
		Brasil.setLayout(new GridLayout(1, 1));
		Brasil.setBounds( 265, 390, 65, 85 );
		Brasil.addMouseListener( getMouseListener() );		
		
		this.add(Brasil);
		//////////////

		
		////////////////////////////
		///////////Europa///////////
		////////////////////////////
		
		/////// Reino Unido/////////
		JPanel ReinoUnido = new JPanel();
		ReinoUnido.setName( "Reino Unido" );
		ReinoUnido.setBackground( Color.BLUE );
		ReinoUnido.setOpaque(false); // Deixa invisivel //
		ReinoUnido.setLayout(new GridLayout(1, 1));
		ReinoUnido.setBounds( 420, 140, 60, 65 );
		ReinoUnido.addMouseListener( getMouseListener() );
		
		this.add(ReinoUnido);
		
		
		/////// Suecia //////////////
		JPanel Suecia = new JPanel();
		Suecia.setName( "Suecia" );
		Suecia.setBackground( Color.BLUE );
		Suecia.setOpaque(false); // Deixa invisivel //
		Suecia.setLayout(new GridLayout(1, 1));
		Suecia.setBounds( 490, 90, 90, 75 );
		Suecia.addMouseListener( getMouseListener() );
		
		this.add(Suecia);
		this.setDefaultCloseOperation(3);
		
		/////// Espanha /////////////
		JPanel Espanha = new JPanel();
		Espanha.setName( "Espanha" );
		Espanha.setBackground( Color.BLUE );
		Espanha.setOpaque(false); // Deixa invisivel //
		Espanha.setLayout(new GridLayout(1, 1));
		Espanha.setBounds( 400, 250, 60, 55 );
		Espanha.addMouseListener( getMouseListener() );
		
		this.add(Espanha);
		
		/////// Franca /////////////
		JPanel Franca = new JPanel();
		Franca.setName( "Franca" );
		Franca.setBackground( Color.BLUE );
		Franca.setOpaque(false); // Deixa invisivel //
		Franca.setLayout(new GridLayout(1, 1));
		Franca.setBounds( 450, 210, 53, 45 );
		Franca.addMouseListener( getMouseListener() );
		
		this.add(Franca);
		
		
		/////// Italia /////////////
		JPanel Italia = new JPanel();
		Italia.setName( "Italia" );
		Italia.setBackground( Color.BLUE );
		Italia.setOpaque(false); // Deixa invisivel //
		Italia.setLayout(new GridLayout(1, 1));
		Italia.setBounds( 510, 210, 40, 75 );
		Italia.addMouseListener( getMouseListener() );
		
		this.add(Italia);
		
		
		/////// Italia /////////////
		JPanel Romenia = new JPanel();
		Romenia.setName( "Romenia" );
		Romenia.setBackground( Color.BLUE );
		Romenia.setOpaque(false); // Deixa invisivel //
		Romenia.setLayout(new GridLayout(1, 1));
		Romenia.setBounds( 553, 230, 30, 65 );
		Romenia.addMouseListener( getMouseListener() );
		
		this.add(Romenia);
		
		
		/////// Polonia /////////////
		JPanel Polonia = new JPanel();
		Polonia.setName( "Polonia" );
		Polonia.setBackground( Color.BLUE );
		Polonia.setOpaque(false); // Deixa invisivel //
		Polonia.setLayout(new GridLayout(1, 1));
		Polonia.setBounds( 553, 170, 30, 50 );
		Polonia.addMouseListener( getMouseListener() );
		
		this.add(Polonia);
		
		
		/////// Ucrania /////////////
		JPanel Ucrania = new JPanel();
		Ucrania.setName( "Ucrania" );
		Ucrania.setBackground( Color.BLUE );
		Ucrania.setOpaque(false); // Deixa invisivel //
		Ucrania.setLayout(new GridLayout(1, 1));
		Ucrania.setBounds( 585, 205, 30, 50 );
		Ucrania.addMouseListener( getMouseListener() );
		
		this.add(Ucrania);
		this.setDefaultCloseOperation(3);
		
		
		////////////////////////////
		//////// Asia ///////////////
		////////////////////////////
		/////// Letonia /////////////
		JPanel Letonia = new JPanel();
		Letonia.setName( "Letonia" );
		Letonia.setBackground( Color.ORANGE );
		Letonia.setOpaque(false); // Deixa invisivel //
		Letonia.setLayout(new GridLayout(1, 1));
		Letonia.setBounds( 600, 165, 115, 40 );
		Letonia.addMouseListener( getMouseListener() );
		
		this.add(Letonia);
		
		/////// Estonia /////////////
		JPanel Estonia = new JPanel();
		Estonia.setName( "Estonia" );
		Estonia.setBackground( Color.ORANGE );
		Estonia.setOpaque(false); // Deixa invisivel //
		Estonia.setLayout(new GridLayout(1, 1));
		Estonia.setBounds( 595, 105, 115, 55 );
		Estonia.addMouseListener( getMouseListener() );
		
		this.add(Estonia);
		
		/////// Russia /////////////
		JPanel Russia = new JPanel();
		Russia.setName( "Russia" );
		Russia.setBackground( Color.ORANGE );
		Russia.setOpaque(false); // Deixa invisivel //
		Russia.setLayout(new GridLayout(1, 1));
		Russia.setBounds( 720, 120, 105, 65 );
		Russia.addMouseListener( getMouseListener() );
		
		this.add(Russia);
		
		/////// Siberia /////////////
		JPanel Siberia = new JPanel();
		Siberia.setName( "Siberia" );
		Siberia.setBackground( Color.ORANGE );
		Siberia.setOpaque(false); // Deixa invisivel //
		Siberia.setLayout(new GridLayout(1, 1));
		Siberia.setBounds( 835, 120, 100, 65 );
		Siberia.addMouseListener( getMouseListener() );
		
		this.add(Siberia);
		
		
		/////// Cazaquistao /////////////
		JPanel Cazaquistao = new JPanel();
		Cazaquistao.setName( "Cazaquistao" );
		Cazaquistao.setBackground( Color.ORANGE );
		Cazaquistao.setOpaque(false); // Deixa invisivel //
		Cazaquistao.setLayout(new GridLayout(1, 1));
		Cazaquistao.setBounds( 770, 190, 130, 40 );
		Cazaquistao.addMouseListener( getMouseListener() );
		
		this.add(Cazaquistao);
		
		
		/////// Turquia /////////////
		JPanel Turquia = new JPanel();
		Turquia.setName( "Turquia" );
		Turquia.setBackground( Color.ORANGE );
		Turquia.setOpaque(false); // Deixa invisivel //
		Turquia.setLayout(new GridLayout(1, 1));
		Turquia.setBounds( 650, 210, 110, 50 );
		Turquia.addMouseListener( getMouseListener() );
		
		this.add(Turquia);
		
		
		/////// Mongolia /////////////
		JPanel Mongolia = new JPanel();
		Mongolia.setName( "Mongolia" );
		Mongolia.setBackground( Color.ORANGE );
		Mongolia.setOpaque(false); // Deixa invisivel //
		Mongolia.setLayout(new GridLayout(1, 1));
		Mongolia.setBounds( 805, 235, 95, 25 );
		Mongolia.addMouseListener( getMouseListener() );
		
		this.add(Mongolia);
		
		/////// Japao /////////////
		JPanel Japao = new JPanel();
		Japao.setName( "Japao" );
		Japao.setBackground( Color.ORANGE );
		Japao.setOpaque(false); // Deixa invisivel //
		Japao.setLayout(new GridLayout(1, 1));
		Japao.setBounds( 915, 220, 30, 75 );
		Japao.addMouseListener( getMouseListener() );
		
		this.add(Japao);
		
		
		/////// Siria /////////////
		JPanel Siria = new JPanel();
		Siria.setName( "Siria" );
		Siria.setBackground( Color.ORANGE );
		Siria.setOpaque(false); // Deixa invisivel //
		Siria.setLayout(new GridLayout(1, 1));
		Siria.setBounds( 615, 263, 90, 26 );
		Siria.addMouseListener( getMouseListener() );
		
		this.add(Siria);
		
		
		/////// Paquistao /////////////
		JPanel Paquistao = new JPanel();
		Paquistao.setName( "Paquistao" );
		Paquistao.setBackground( Color.ORANGE );
		Paquistao.setOpaque(false); // Deixa invisivel //
		Paquistao.setLayout(new GridLayout(1, 1));
		Paquistao.setBounds( 720, 263, 35, 70 );
		Paquistao.addMouseListener( getMouseListener() );
		
		this.add(Paquistao);
		
		
		/////// China /////////////
		JPanel China = new JPanel();
		China.setName( "China" );
		China.setBackground( Color.ORANGE );
		China.setOpaque(false); // Deixa invisivel //
		China.setLayout(new GridLayout(1, 1));
		China.setBounds( 765, 235, 35, 90 );
		China.addMouseListener( getMouseListener() );
		
		this.add(China);
		
		
		/////// Coreia do Norte /////////////
		JPanel Coreia_do_Norte = new JPanel();
		Coreia_do_Norte.setName( "Coreia do Norte" );
		Coreia_do_Norte.setBackground( Color.ORANGE );
		Coreia_do_Norte.setOpaque(false); // Deixa invisivel //
		Coreia_do_Norte.setLayout(new GridLayout(1, 1));
		Coreia_do_Norte.setBounds( 825, 285, 70, 20 );
		Coreia_do_Norte.addMouseListener( getMouseListener() );
		
		this.add(Coreia_do_Norte);
		
		
		/////// Coreia do Sul /////////////
		JPanel Coreia_do_Sul = new JPanel();
		Coreia_do_Sul.setName( "Coreia do Sul" );
		Coreia_do_Sul.setBackground( Color.ORANGE );
		Coreia_do_Sul.setOpaque(false); // Deixa invisivel //
		Coreia_do_Sul.setLayout(new GridLayout(1, 1));
		Coreia_do_Sul.setBounds( 810, 310, 90, 20 );
		Coreia_do_Sul.addMouseListener( getMouseListener() );
		
		this.add(Coreia_do_Sul);
		
		
		/////// Tailandia /////////////
		JPanel Tailandia = new JPanel();
		Tailandia.setName( "Tailandia" );
		Tailandia.setBackground( Color.ORANGE );
		Tailandia.setOpaque(false); // Deixa invisivel //
		Tailandia.setLayout(new GridLayout(1, 1));
		Tailandia.setBounds( 860, 335, 45, 90 );
		Tailandia.addMouseListener( getMouseListener() );
		
		this.add(Tailandia);
		
		
		/////// Bangladesh /////////////
		JPanel Bangladesh = new JPanel();
		Bangladesh.setName( "Bangladesh" );
		Bangladesh.setBackground( Color.ORANGE );
		Bangladesh.setOpaque(false); // Deixa invisivel //
		Bangladesh.setLayout(new GridLayout(1, 1));
		Bangladesh.setBounds( 820, 335, 35, 90 );
		Bangladesh.addMouseListener( getMouseListener() );
		
		this.add(Bangladesh);
		
		
		/////// India /////////////
		JPanel India = new JPanel();
		India.setName( "India" );
		India.setBackground( Color.ORANGE );
		India.setOpaque(false); // Deixa invisivel //
		India.setLayout(new GridLayout(1, 1));
		India.setBounds( 765, 335, 45, 90 );
		India.addMouseListener( getMouseListener() );
		
		this.add(India);
		
		
		/////// Ira /////////////
		JPanel Ira = new JPanel();
		Ira.setName( "Ira" );
		Ira.setBackground( Color.ORANGE );
		Ira.setOpaque(false); // Deixa invisivel //
		Ira.setLayout(new GridLayout(1, 1));
		Ira.setBounds( 685, 295, 30, 65 );
		Ira.addMouseListener( getMouseListener() );
		
		this.add(Ira);
		
		
		/////// Iraque /////////////
		JPanel Iraque = new JPanel();
		Iraque.setName( "Iraque" );
		Iraque.setBackground( Color.ORANGE );
		Iraque.setOpaque(false); // Deixa invisivel //
		Iraque.setLayout(new GridLayout(1, 1));
		Iraque.setBounds( 650, 295, 30, 65 );
		Iraque.addMouseListener( getMouseListener() );
		
		this.add(Iraque);
		
		
		
		/////// Jordania /////////////
		JPanel Jordania = new JPanel();
		Jordania.setName( "Jordania" );
		Jordania.setBackground( Color.ORANGE );
		Jordania.setOpaque(false); // Deixa invisivel //
		Jordania.setLayout(new GridLayout(1, 1));
		Jordania.setBounds( 600, 295, 38, 65 );
		Jordania.addMouseListener( getMouseListener() );
		
		this.add(Jordania);
		
		
		/////// Arabia Saudita /////////////
		JPanel  Arabia_Saudita = new JPanel();
		Arabia_Saudita.setName( "Arabia Saudita" );
		Arabia_Saudita.setBackground( Color.ORANGE );
		Arabia_Saudita.setOpaque(false); // Deixa invisivel //
		Arabia_Saudita.setLayout(new GridLayout(1, 1));
		Arabia_Saudita.setBounds( 630, 370, 70, 50 );
		Arabia_Saudita.addMouseListener( getMouseListener() );
		
		this.add(Arabia_Saudita);
		
		
		
		////////////////////////////
		////////Africa//////////////
		////////////////////////////
		
		/////// Argelia /////////////
		JPanel  Argelia = new JPanel();
		Argelia.setName( "Argelia" );
		Argelia.setBackground( Color.MAGENTA );
		Argelia.setOpaque(false); // Deixa invisivel //
		Argelia.setLayout(new GridLayout(1, 1));
		Argelia.setBounds( 420, 320, 85, 65 );
		Argelia.addMouseListener( getMouseListener() );
		
		this.add(Argelia);
		
		
		/////// Egito /////////////
		JPanel  Egito = new JPanel();
		Egito.setName( "Egito" );
		Egito.setBackground( Color.MAGENTA );
		Egito.setOpaque(false); // Deixa invisivel //
		Egito.setLayout(new GridLayout(1, 1));
		Egito.setBounds( 525, 340, 70, 65 );
		Egito.addMouseListener( getMouseListener() );
		
		this.add(Egito);
		
		
		/////// Nigeria /////////////
		JPanel  Nigeria = new JPanel();
		Nigeria.setName( "Nigeria" );
		Nigeria.setBackground( Color.MAGENTA );
		Nigeria.setOpaque(false); // Deixa invisivel //
		Nigeria.setLayout(new GridLayout(1, 1));
		Nigeria.setBounds( 440, 410, 115, 45 );
		Nigeria.addMouseListener( getMouseListener() );
		
		this.add(Nigeria);
		
		
		/////// Angola /////////////
		JPanel  Angola = new JPanel();
		Angola.setName( "Angola" );
		Angola.setBackground( Color.MAGENTA );
		Angola.setOpaque(false); // Deixa invisivel //
		Angola.setLayout(new GridLayout(1, 1));
		Angola.setBounds( 510, 460, 70, 50 );
		Angola.addMouseListener( getMouseListener() );
		
		this.add(Angola);
		
		
		/////// Somalia /////////////
		JPanel  Somalia = new JPanel();
		Somalia.setName( "Somalia" );
		Somalia.setBackground( Color.MAGENTA );
		Somalia.setOpaque(false); // Deixa invisivel //
		Somalia.setLayout(new GridLayout(1, 1));
		Somalia.setBounds( 585, 425, 60, 80 );
		Somalia.addMouseListener( getMouseListener() );
		
		this.add(Somalia);
		
		
		/////// Africa do Sul /////////////
		JPanel  Africa_do_Sul = new JPanel();
		Africa_do_Sul.setName( "Africa do Sul" );
		Africa_do_Sul.setBackground( Color.MAGENTA );
		Africa_do_Sul.setOpaque(false); // Deixa invisivel //
		Africa_do_Sul.setLayout(new GridLayout(1, 1));
		Africa_do_Sul.setBounds( 530, 520, 75, 50 );
		Africa_do_Sul.addMouseListener( getMouseListener() );
		
		this.add(Africa_do_Sul);
		
		
		////////////////////////////
		//////// Oceania/////////////
		////////////////////////////
	//	//////// Perth /////////////		
		JPanel  Perth = new JPanel();
		Perth.setName( "Perth" );
		Perth.setBackground( Color.GRAY );
		Perth.setOpaque(false); // Deixa invisivel //
		Perth.setLayout(new GridLayout(1, 1));
		Perth.setBounds( 740, 520, 75, 75 );
		Perth.addMouseListener( getMouseListener() );
		
		this.add(Perth);
		
		
		//	//////// Australia /////////////		
		JPanel  Australia = new JPanel();
		Australia.setName( "Australia" );
		Australia.setBackground( Color.GRAY );
		Australia.setOpaque(false); // Deixa invisivel //
		Australia.setLayout(new GridLayout(1, 1));
		Australia.setBounds( 835, 530, 65, 95 );
		Australia.addMouseListener( getMouseListener() );
		
		this.add(Australia);
		
		
		//	//////// Nova Zelandia /////////////		
		JPanel  Nova_Zelandia = new JPanel();
		Nova_Zelandia.setName( "Nova Zelandia" );
		Nova_Zelandia.setBackground( Color.GRAY );
		Nova_Zelandia.setOpaque(false); // Deixa invisivel //
		Nova_Zelandia.setLayout(new GridLayout(1, 1));
		Nova_Zelandia.setBounds( 905, 560, 35, 75 );
		Nova_Zelandia.addMouseListener( getMouseListener() );
		
		this.add(Nova_Zelandia);
		
		this.setVisible(true);
		
		//	//////// Indonesia /////////////		
		JPanel  Indonesia = new JPanel();
		Indonesia.setName( "Indonesia" );
		Indonesia.setBackground( Color.GRAY );
		Indonesia.setOpaque(false); 
		Indonesia.setLayout(new GridLayout(1, 1));
		Indonesia.setBounds( 805, 460, 115, 35 );
		Indonesia.addMouseListener( getMouseListener() );
		
		this.add(Indonesia);
		
		this.setVisible(true);
		
	}

	private static MouseListener getMouseListener()
	{
		return new MouseAdapter()
		{
			@Override
			public void mouseClicked( MouseEvent e )
			{
				if (ControlaView.getInicializaView().getFaseCtrl()!= 2 && ControlaView.getInicializaView().getFaseCtrl()!=3) {
					System.out.println( ( ( JComponent ) e.getSource() ).getName() );
					int qtdExercitos =	Ctrl.getInstance().registra(getCxTabuleiro()).getNumExercitos(( ( JComponent ) e.getSource() ).getName());

					String dono = Ctrl.getInstance().registra(getCxTabuleiro()).getCorDonoTerritorio( ( ( JComponent ) e.getSource() ).getName());

					String msg = "Quantidade de Ex�rcitos: "+qtdExercitos+"\nCor do Dono: "+dono;
					JOptionPane.showMessageDialog(null, msg,( ( JComponent ) e.getSource() ).getName(),JOptionPane.INFORMATION_MESSAGE);
				}
				
				
				switch(ControlaView.getInicializaView().getFaseCtrl()) {
					case 2:
						corJog = Ctrl.getInstance().registra(getCxTabuleiro()).getCorDonoTerritorio( ( ( JComponent ) e.getSource() ).getName());
						// Define QtdExAtk //
						ControlaView.getInicializaView().setQtdExAtk(Ctrl.getInstance().registra(getCxTabuleiro()).getNumExercitos(( ( JComponent ) e.getSource() ).getName()));
						
						setAtacante(( ( JComponent ) e.getSource() ).getName());
						JOptionPane.showMessageDialog(null, "Selecione o territ�rio defensor",null,JOptionPane.INFORMATION_MESSAGE);

						break;
					case 3:
						
						// Define QtdExDef //
						ControlaView.getInicializaView().setQtdExDef(Ctrl.getInstance().registra(getCxTabuleiro()).getNumExercitos(( ( JComponent ) e.getSource() ).getName()));
						setDefensor(( ( JComponent ) e.getSource() ).getName());
						break;			
				}
				
			}
		};
	}
	
	private static void  setAtacante(String territorioAtacante)
	{
		
		JOptionPane.showMessageDialog(null,"Territ�rio atacante: "+territorioAtacante,null,JOptionPane.INFORMATION_MESSAGE); 
		ControlaView.getInicializaView().setTerritorioAtk(territorioAtacante);
		ControlaView.getInicializaView().setFaseJogada(3);
		

	}
	private static void setDefensor(String territorioDefensor) {
		ControlaView.getInicializaView().setTerritorioDef(territorioDefensor);
		JOptionPane.showMessageDialog(null,"Territ�rio defensor: "+territorioDefensor,null,JOptionPane.INFORMATION_MESSAGE); 
		
		if (ControlaJogo.getControlaJogo().verificaAtaque(ControlaView.getInicializaView().getTerritorioAtk(), territorioDefensor, corJog)==true) {
			System.out.println("O ataque pode ser realizado");
			// Seta a cor do jogador Atacante //
			ControlaView.getInicializaView().setCorAtk(corJog);
			// Apresenta a tela para jogar os dados //
			int dAtk = ControlaView.getInicializaView().getQtdExAtk()-1;
			int dDef = ControlaView.getInicializaView().getQtdExDef();
			if ( dAtk > 3) {
				dAtk =3;
			}
			if ( dDef > 3) {
				dDef = 3;
			}
			new CxExibeDados(dAtk,dDef);
			ControlaView.getInicializaView().setFaseJogada(4);
		}
		else {
			System.out.println("O ataque n�o pode ser realizado");
			ControlaView.getInicializaView().setFaseJogada(2);
			JOptionPane.showMessageDialog(null, "Selecione o territ�rio atacante",null,JOptionPane.INFORMATION_MESSAGE);

		}
		
	}

	@Override
	public void add(ObservadorIF o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(ObservadorIF o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int get(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	// Caso haja uma mudan�a em uma vari�vel, alterar aqui //1
	public void notify(ObservadoIF o) {
		
	}


}
