package View;
import Model.*;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Controller.ControlaJogo;


class CxRecebeExercitos extends JFrame {
	
		private JFrame frame = new JFrame();
		
		
		
		
		public CxRecebeExercitos(int posjogAlvo) {
		
		
		
		frame.setLayout(new FlowLayout());
		frame.setTitle("Recebimento de Ex�rcitos");
		frame.setSize(350, 70);
		frame.setLocation(1470, 620);
		frame.setVisible(true);
		
		JButton recebeButton = new JButton();
		recebeButton.setText("Receber Ex�rcitos");
		recebeButton.addActionListener((ActionEvent e) -> recebeExercitos(posjogAlvo));
		recebeButton.setVisible(true);
		frame.add(recebeButton);
		
	}
	
	public void recebeExercitos(int posjogAlvo) {
		frame.setVisible(false);
		int qtd = ControlaJogo.getControlaJogo().recebeEx(posjogAlvo);
		String s = "O Jogador recebeu "+qtd+" ex�rcitos";
		JOptionPane.showMessageDialog(null, s,null,JOptionPane.INFORMATION_MESSAGE); 
		
		
		// Colocar em observer //
		String S[] = Acoes.getAcoes().getListaTerritoriosString(posjogAlvo);
		//	//	//	//	//	//
		ControlaView.getInicializaView().setQtdEx(qtd);
		//ControlaView.getInicializaView().inicializaControleJogadas(2,posjogAlvo);

		
		CxPosicionaExercitos.getCxPosicionaExercitos(qtd, S);
		
	}


}
