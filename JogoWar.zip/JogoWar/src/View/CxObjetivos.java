package View;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Model.Acoes;

public class CxObjetivos extends JFrame{
	
	
	
	private JButton[] exibeObjetivo;
	
	public CxObjetivos(int qtdJogador) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Objetivos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		BoxLayout boxlayout = new BoxLayout(panel,BoxLayout.Y_AXIS);
		panel.setLayout(boxlayout);
		String nomes[] = new String[qtdJogador];
		nomes = Acoes.getAcoes().getNomesJogadores();		
		
		frame.setLocation(1472, 135);
		exibeObjetivo = new JButton[qtdJogador];
		
		for ( int i=0; i < qtdJogador;i++) {
			
			exibeObjetivo[i] = new JButton("Objetivos do Jogador "+nomes[i]);
			exibeObjetivo[i].setAlignmentX(Component.CENTER_ALIGNMENT);
			exibeObjetivo[i].addMouseListener(getMouseListener(nomes[i]));
			panel.add(exibeObjetivo[i]);
		}
		
		
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
        
         exibeObjetivo[0].addMouseListener(getMouseListener(nomes[0]));
        
		
	}
	
	private static MouseListener getMouseListener(String nome)
	{
		return new MouseAdapter()
		{
			@Override			
			public void mouseClicked( MouseEvent e )
			{
				CxExibeObjetivo O = new CxExibeObjetivo(nome);
				
			}
		};
	}
	

}
