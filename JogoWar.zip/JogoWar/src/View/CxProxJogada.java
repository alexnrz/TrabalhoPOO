package View;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

class CxProxJogada extends JFrame{
	
	private static JFrame frame = new JFrame();
	private static int faseRodada;
	private static int jogRodada;
	
	private static CxProxJogada ctrl = null;
	
	public static CxProxJogada getCxProxJogada(int fase,int jog) {
		
		if (ctrl==null) {
			faseRodada=fase;
			jogRodada = jog;
			ctrl = new CxProxJogada();
		}
		else {
			frame.setVisible(true);
			faseRodada= fase;
			jogRodada = jog;
		}
		
		return ctrl;
	}
	
	private CxProxJogada() {
		
		
		frame.setTitle("Pr�xima Jogada");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
		frame.setLayout(new GridLayout(1,2));
		
		frame.setBounds(1470, 480, 285, 135);
		
		JButton proxButton = new JButton();
		proxButton.setIcon(new ImageIcon(getClass().getResource( "/Img/war_btnProxJogada.png")));
		proxButton.setSize(55,45);
		proxButton.addActionListener((ActionEvent e) -> proxJogada(faseRodada,jogRodada));
		frame.add(proxButton);
		frame.setVisible(true);
		
		
		
		
	}
	
	public void proxJogada(int faseRodada,int jogRodada) {
		
		if(faseRodada == 1) {
			
			new CxRecebeExercitos(jogRodada);
			frame.setVisible(false);
			
			
		}
		if (faseRodada == 2) {
			
			
			ControlaView.getInicializaView().setFaseJogada(2);
			JOptionPane.showMessageDialog(null, "FASE DE ATAQUE"); 

			JOptionPane.showMessageDialog(null, "Selecione o territ�rio atacante",null,JOptionPane.INFORMATION_MESSAGE);
			frame.setVisible(false);

		}
		if(faseRodada == 4) {
			frame.repaint();
			frame.setVisible(false);
			
			CxPerguntaDeslocamento.getCxPerguntaDeslocamento();
			System.out.println("FASE 4");
			
		}
		
		
		
		
		
	}

}
