package View;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

class CxProxJogada extends JFrame{
	
	private JFrame frame = new JFrame();
	
	private static CxProxJogada ctrl = null;
	
	public static CxProxJogada getCxProxJogada(int fase,int jogRodada) {
		
		if (ctrl==null) {
			ctrl = new CxProxJogada(fase,jogRodada);
		}
		
		return ctrl;
	}
	
	private CxProxJogada(int faseRodada, int jogRodada) {
		
		
		frame.setTitle("Pr�xima Jogada");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
		frame.setLayout(new GridLayout(1,2));
		
		frame.setBounds(1470, 480, 285, 135);
		
		JButton proxButton = new JButton();
		proxButton.setIcon(new ImageIcon(getClass().getResource( "/Img/war_btnProxJogada.png")));
		proxButton.setSize(55,45);
		proxButton.addActionListener((ActionEvent e) -> proxJogada(faseRodada,jogRodada));
		frame.add(proxButton);
		frame.setVisible(true);
		
		
		
		
	}
	
	public void proxJogada(int faseRodada,int jogRodada) {
		
		if(faseRodada == 1) {
			
			frame.dispose();
			new CxRecebeExercitos(jogRodada);
			ctrl =null;
			
			
			
		}
		if (faseRodada == 2) {
			
			ControlaView.getInicializaView().setFaseJogada(2);
			frame.repaint();
			frame.setVisible(false);
			JOptionPane.showMessageDialog(null, "FASE DE ATAQUE"); 

			JOptionPane.showMessageDialog(null, "Selecione o territ�rio atacante",null,JOptionPane.INFORMATION_MESSAGE);
						
		}
		if(faseRodada ==4) {
			frame.repaint();
			frame.setVisible(true);
		}
		
		
		
		
		
	}

}
