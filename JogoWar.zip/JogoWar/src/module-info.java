module JogoWar {
	requires java.desktop;
}