package Controller;

public interface ObservadorIF {
	
	public void notify(Observado o);

}
