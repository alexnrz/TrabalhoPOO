package Controller;

import Model.*;

public class Inicializa {
	
	Acoes A = new Acoes();
	String[] nomes;
	String[] cores;
	int qtdJogadores;
	
	protected void inicializa() {
		
		boolean resposta;
		
		resposta = A.inicializaJogo(nomes, cores);
		
		if ( resposta == false) {
			System.out.println("Erro ao iniciar o jogo no Controller");
		}
	}
	
	public void setQtdJogadores(int qtd) {
		qtdJogadores = qtd;
		nomes = new String[qtd];
		cores = new String[qtd];
		for(int i=0; i<qtd;i++) {
			nomes[i] = new String();
			cores[i] = new String();
		}
	}
	
	public void setNomes(String nm) {
		
		for (int i=0;i<nomes.length;i++) {
			if(nomes[i]==null) {
				nomes[i]=nm;
				break;
			}
		}

	}
	
	public void setCores(String cr) {

		for( int i=0; i < cores.length; i++) {
			if(cores[i]==null) {
				cores[i]=cr;
				break;
			}
		}
	}
	


}
