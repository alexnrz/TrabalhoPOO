package Controller;

import Model.*;
import View.*;

// Padr�o Singleton //
public class Inicializa {
	
	
	
	String[] nomes;
	String[] cores;
	int qtdJogadores;
	
	
	// Main //

	
	private static Inicializa ctrl = null;
	
	private Inicializa() {}	
	
	public static Inicializa getInicicializa() {
		if ( ctrl ==null) {
			ctrl=new Inicializa();
		}
		
		return ctrl;
		
		 
	}	
	
	
	
	
	// M�todos da Classe //
	
		
	public boolean inicializaPartida() {
		boolean resposta;
		
		
		
		 resposta = Acoes.getAcoes().inicializaJogo(nomes, cores);
		
		if ( resposta == false) {
			System.out.println("Erro ao iniciar o jogo no Controller");
		}
		return true;
	}
	
	
	// Defini��es Inicias da partida: Nomes dos jogadores, Cores e 
	// a quantidade de jogadores
	public void setQtdJogadores(int qtd) {
		qtdJogadores = qtd;
		nomes = new String[qtd];
		cores = new String[qtd];
	}
	
	public void setNomes(String nm) {
		for (int i=0;i<nomes.length;i++) {
			if(nomes[i]==null) {
				nomes[i]=nm;
				break;
			}
		}

	}
	
	public void setCores(String cr) {

		for( int i=0; i < cores.length; i++) {
			if(cores[i]==null) {
				cores[i]=cr;
				break;
			}
		}
	}
	


}
