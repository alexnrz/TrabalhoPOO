package Controller;

public interface Observado {
	
	public void add(ObservadorIF o);
	
	public void remove(ObservadorIF o);
	
	public int get();
	
	

}
