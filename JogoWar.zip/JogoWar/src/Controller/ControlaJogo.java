package Controller;
//Alex Nascimento Rodrigues 
//Pedro de Aguiar Alves da Silva Menezes

import Model.*;
import View.*;

// Padr�o Singleton //
public class ControlaJogo {
	
	
	int jogDaVez =0;
	int []ordemJogadores;

	int qtdJogadores;
	
	
	// Main //
	public static void main(String[] args) {	
		ControlaView.getInicializaView().iniciaPartida();
		
		
	}
	

	
	private static ControlaJogo ctrl = null;
	
	private ControlaJogo() {}	
	
	public static ControlaJogo getControlaJogo() {
		if ( ctrl ==null) {
			ctrl=new ControlaJogo();
		}
		
		return ctrl;
		
		 
	}	
	
	// Recebe a Ordem dos jogadores do Model e seta//
	public void setOrdemJogadores() {		
		ordemJogadores = Acoes.getAcoes().getOrdemJogadores();
				
	}
	
	// Passa a Vez do Jogador //
	public void setJogDaVez(int jogAnterior) {
		
		// �ltimo jogador da rodada ja jogou //
		if(jogAnterior == ordemJogadores[ordemJogadores.length-1]==true) {
			jogDaVez = 0;
		}
		else {
			jogDaVez = jogDaVez + 1;
		}
		
	}
	
	public int getJogDaVez() {
		return jogDaVez;
	}
	
	
	// M�todos para utiliza��o do Model //	
	public boolean inicializaPartida() {
		boolean resposta;
		
		
		
		 resposta = Acoes.getAcoes().inicializaJogo();
		
		if ( resposta == false) {
			System.out.println("Erro ao iniciar o jogo no Controller");
		}
		return true;
	}
	 
	
	public int recebeEx(int posjogAlvo) {
		
		int qtdEx = Acoes.getAcoes().recebeExercitos(Acoes.getAcoes().getJogadorAlvo(posjogAlvo));
		return qtdEx;
	}
	
	
	
	
	
	// Defini��es Inicias da partida: Nomes dos jogadores, Cores e 
	// a quantidade de jogadores
	public void setQtdJogadores(int qtd) {
		qtdJogadores = qtd;
		Acoes.getAcoes().setQtdJogadores(qtd);
	}
	

	
	// Dados //
	public void setResultadoDados(int Dado1[], int Dado2[]) {
		Acoes.getAcoes().setDadoAtk(Dado1);
		Acoes.getAcoes().setDadoDef(Dado2);
	}
	

	public int getResultadoDado() {
		 
		int Valor =	Acoes.getAcoes().getResultadoDado();
		
		return Valor;
		 
		 
		 
	}
	
	public void adicionaExercitosTerritorio(int qtdEx, String territorioAlvo) {
		Acoes.getAcoes().getListaTerritorios();
	}
	
	

}
