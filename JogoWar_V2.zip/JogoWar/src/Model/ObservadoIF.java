package Model;

import java.awt.Color;

public interface ObservadoIF {
	
	public void add(ObservadorIF o);
	public void remove(ObservadorIF o);
	
	public int get(int i);
	
	public String[] getNomesJogadores();
	public int getNumExercitos(String nomeTerritorio);
	public String getCorDonoTerritorio(String nomeTerritorio);
	public Color getCorTerritorioJava(String nomeTerritorio);
	public void adicionaExercitoTerritorio(int qtd, String territorioAlvo);
	public boolean DeslocaExercitos(String territorioDoador,String territorioRecebedor, int qtdExRetirar);
	public void setCores(String cor);
	public void setNomes(String nm);
	public void setQtdJogadores(int n);

}
