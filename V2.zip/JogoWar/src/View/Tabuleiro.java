package View;

import Observers.*;

public class Tabuleiro implements ObserverIF{
	public void update()
	{
		// Implementar
	}

}