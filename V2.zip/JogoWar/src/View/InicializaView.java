package View;

import Observers.*;

public class InicializaView implements ObserverIF{
	
	
	
	
	private static InicializaView ctrl = null;
	
	private InicializaView(){}
	
	public static InicializaView getInicializaView() {
		if(ctrl == null) {
			ctrl = new InicializaView();
		}
		return ctrl;
	}
	
	public void inicilizaInfosIniciais() {
		
		
		
	}
	
	public void update()
	{
		// Implementar
	}

}
