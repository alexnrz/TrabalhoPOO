package Observers;

public interface SubjectIF {

	int getState();

	void setState(int state);

	void attach(Observer observer);

	void remove(ObserverIF observer);

	void notifyAllObservers();

}