package Observers;
import java.util.ArrayList;
import java.util.List;

public class Subject implements SubjectIF {
	
   private List<Observer> observers = new ArrayList<Observer>();
   private int state;

   @Override
public int getState() {
      return state;
   }

   @Override
public void setState(int state) {
      this.state = state;
      notifyAllObservers();
   }

   @Override
public void attach(Observer observer){
      observers.add(observer);		
   }
   @Override
public void remove (ObserverIF observer){
	   observers.remove(observer);		
   }

   @Override
public void notifyAllObservers(){
      for (ObserverIF observer : observers) {
         observer.update();
      }
   } 	
}
