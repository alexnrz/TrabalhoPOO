package Observers;

public abstract class Observer implements ObserverIF {
	   protected SubjectIF subject;
	   @Override
	   public abstract void update();
	   
	   public void getSubject (Subject sub)
	   {
		   subject = sub;
	   }
}
