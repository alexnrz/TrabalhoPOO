package Observers;

public interface ObserverIF {

	void update();

}