package Model;
import java.util.Scanner;
import Observers.*;

/*Eu n�o adiconei a fun��o de notificar as a��es. */

// Padr�o Singleton //
public class Acoes extends  Subject{
	Scanner numE = new Scanner(System.in);
	static int numeroDeTerritorios = 9; // N�mero de pa�ses //	
	static int numContinentes = 2;
		
	static Continente[] Continentes;
	static Territorio[] listaTerritorios;
	private Exercito[] Exercitos;
	private Objetivo[] Objetivos;
	private Cartas C;
	private Jogador[] listaJogadores;
	boolean respInicializaJogo;
	
	private static Acoes ctrl = null;
	
	private Acoes() {}
	
	public static Acoes getAcoes() {
		if( ctrl == null) {
			ctrl = new Acoes();
		}
		
		return ctrl;
	} 
	
	
	// Verifica se o jogo pode ser iniciado, se sim inicia //
	public boolean inicializaJogo(String[] StrJogadores, String[] CorJogadores) {
		
		if(StrJogadores[0]==null) {
			System.out.println("Erro ao receber os nomes dos Jogadores!");
			return false;
		}
		if(CorJogadores[0]==null) {
			System.out.println("Erro ao receber as cores dos Jogadores!");
			return false;
		}
		
		respInicializaJogo = InicializaComponentes.getInicializaComponentes().inicializaTudo(Continentes, listaTerritorios, listaJogadores, Objetivos, Exercitos, C, StrJogadores, CorJogadores);
		if( respInicializaJogo == false) {
			System.out.println("Erro ao inicializar o Jogo!");
			return false;
		}
		
		return true;
		
	}
	/*
	private boolean validaAtaque(String cor,String nomeTOrigem,String nomeTDestino){
			
		InicializaComponentes a = new InicializaComponentes();
		Jogador[] J = a.getListaJogadores();
		Territorio[] T;
		String[] S;
		int i=0;
		boolean terr = false;
		
		while(J[i].getColor().equals(cor) == false) {
			i++;
		}
		
		T = J[i].getListaTerritorios();
		
		// Verifica se o jogador possui este territ�rio //
		for ( i =0; i < T.length;i++) {
			if(T[i].getNomeTerritorio().equals(nomeTOrigem) == true) {
				terr= true;
				break;
			}
		}
		if ( terr == false) {
			System.out.println("O Territ�rio n�o � do Jogador");
			return false;
		}
		S = T[i].getFronteiras();
		
		terr = false;
		
		// Verifica se existe Fronteira entre os dois //
		for (i=0;i<S.length;i++) {
			if (S[i].equals(nomeTDestino) ) {
				terr=true;
				break;
			}			
		}
		
		if (terr==false) {
			System.out.println("O Territ�rio de Origem n�o faz fronteira com o Teerit�rio DEstino");
		}
		
		return true;
	}
	*/
	
	protected void recebeExercitos(Jogador[] listaJogadores, String jogadorAlvo,Territorio[] listaTerritorios) {
		
	
		Continente[] C = getListaContinentes();
		int i=0,numExercitos=0,numTemp=0,contador=0,Contp=0;
		boolean sinal = false;
		String sTemp;
		Territorio[] T;
		Territorio[] TCont = new Territorio[8];
		while(listaJogadores[i].getnomeJogador().equals(jogadorAlvo) == false) {
			i++;
		}
		
		// Verifica se tem exercitos bonus para receber //
		T = listaJogadores[i].getListaTerritorios();
		System.out.println("JOGADOR ALVO: "+listaJogadores[i].getnomeJogador());
		System.out.println("Territorios do Jogador:");
		for(int j=0; j < listaJogadores[i].getnumTerritoriosJog();j++) {
			if(T[j].getNomeTerritorio()!=null) {
				System.out.println("   " + T[j].getNomeTerritorio());
			}
		}
		
		for(int k=0; k < C.length; k++) {
			TCont=C[k].getTerritoriosContinente();
			for ( int z=0; z < C[0].getNumTerritorios();z++) {
				for (int j=0; j < listaJogadores[i].getnumTerritoriosJog();j++) {
					if(TCont[z].getNomeTerritorio().equals(T[j].getNomeTerritorio()) == true) {
						contador = contador + 1;
						break;
					}
				}
			}
			// Caso true, o jogador possui o b�nus por esse continente //
			if (contador == C[k].getNumTerritorios()) {
				Contp = Contp+1;
			}		
			contador=0;
		}
		
		// B�nus atualmente � de 2 por Continente //
		// Contp = exercitos b�nus //
		
		numExercitos = (2*Contp) + (listaJogadores[i].getnumTerritoriosJog())/2;
		
		listaJogadores[i].setNumExercitos(listaJogadores[i].getNumExercitos()+numExercitos);
		

		while(numExercitos>0) {
			System.out.println("Voc� possui "+numExercitos+" unidades de Exercito dispon�veis");
			System.out.println("Quantos unidades deseja colocar no territ�rio alvo?");
			
			numTemp = numE.nextInt();
			if(numTemp > numExercitos) {
				System.out.println("Essa quantidade n�o est� dispon�vel!!");
			}
			else {
				System.out.println("Qual territ�rio deseja colocar suas unidades?");
				
				sTemp = numE.next();
				
				// Verifica se o Territorio pertence ao jogador //
				for(i=0;i<listaTerritorios.length;i++) {
					if(listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
						if(listaTerritorios[i].getdonoTerritorio().equals(jogadorAlvo) == true) {
							sinal = true;
						}
					}
				}
				// Coloca as unidades no territorio alvo caso seja //
				if (sinal == true) {
					for (i=0; i <listaTerritorios.length;i++) {
						if (listaTerritorios[i].getNomeTerritorio().equals(sTemp) == true) {
							listaTerritorios[i].setNumExercitos(listaTerritorios[i].getnumExercitos()+numTemp);
						}
					}
					numExercitos = numExercitos - numTemp;
				}
				else {
					System.out.println("Este territ�rio n�o pertence ao jogador");
				}
				
				
			}
			sinal = false;
			
			
			
		}		
	}

		
	public Jogador[] getListaJogadores() {
		return listaJogadores;
	}
	
	public Territorio[] getListaTerritorios() {
		return listaTerritorios;
	}
	
	public Exercito[] getListaExercitos() {
		return Exercitos;
	}
	
	public Continente[] getListaContinentes() {
		return Continentes;
	}

}


